package com.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cxstock.dao.DqkcDAO;
import com.service.SearchBiz;

@SuppressWarnings("unchecked")
@Service
@Transactional
public class SearchBizImpl implements SearchBiz {
	@Resource
	private DqkcDAO dqkcDao;
	public void setDqkcDao(DqkcDAO dqkcDao) {
		this.dqkcDao = dqkcDao;
	}

	/*
	 * 库存查询
	 */
	public List findKcByParams(Integer kfid,Integer lbid,String search) {
		return dqkcDao.getDqkcByParams(kfid, lbid, search);
	}

	/*
	 * 库存报警
	 */
	public List findBaoJingSpxx() {
		String hql = "from Spxx as t where t.kcsl<=t.minnum";
		return dqkcDao.findByHql(hql);
	}
	


}
