package com.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cxstock.dao.BaseDAO;
import com.cxstock.utils.pubutil.TreeNode;
import com.pojo.Position;
import com.service.PositionBiz;

@Transactional
@Service
public class PositionBizImpl implements PositionBiz {

	@Resource
	private BaseDAO baseDao;
	public void setBaseDao(BaseDAO baseDao) {
		this.baseDao = baseDao;
	}
	
	@Override
	public Integer saveOrUpdatePosition(Position position) {
		if(position.getSpid()!=null){
			position = (Position)baseDao.loadById(Position.class, position.getSpid());
		}else{
			position.setPid(position.getPid());
		}
		baseDao.saveOrUpdate(position);
		return position.getSpid();
	}
	
	@Override
	public boolean deletePosition(Integer spid) {
		int count = baseDao.countQuery("select count(*) from Position where spid = "+spid);
		if(count>0){
			return false;
		}
		baseDao.deleteById(Position.class, spid);
		return true;
	}
	@Override
	public List findPositionTree() {
		List list = baseDao.listAll("Position");
		return this.getTree(0, list);
	}
	
	/**  
	 * 通过递归生成tree结构  
	 * @param List childrenlist 商品类别集合
	 * @param Integer id 节点（父节点id）
	 */
	private List getTree(Integer id,List childrenlist) {
		List resultlist = new ArrayList();

		//当前级菜单集合
		List list = this.getChildrens(childrenlist, id);
		for (Object obj : list) {
			Position splb = (Position) obj;

			TreeNode treeNode = new TreeNode();
			treeNode.setId(splb.getSpid().toString());
			treeNode.setText(splb.getSpname());
			treeNode.setIconCls("menu-folder");
			//子菜单
			List children = this.getChildrens(childrenlist, splb.getSpid());
			if (children.size() > 0) {//有子类别集合
				treeNode.setLeaf(false);
				treeNode.setChildren(getTree(splb.getSpid(),childrenlist)); //递归调   
			} else {//该节点为叶子    
				treeNode.setLeaf(true);
			}
			resultlist.add(treeNode);
		}
		return resultlist;
	}

	/**
	 * 从funcs集合中找出父节点id为pid的类别集合
	 * @param List menus 类别集合
	 * @param Integer pid 父节点id
	 * return List
	 */
	private List getChildrens(List splbs, Integer pid) {
		List resultList = new ArrayList();
		Position splb = null;
		for (Object obj : splbs) {
			splb = (Position) obj;
			if (splb.getPid()!=null&&splb.getPid().equals(pid)) {//父节点id
				resultList.add(splb);
			}
		}
		return resultList;
	}
}
