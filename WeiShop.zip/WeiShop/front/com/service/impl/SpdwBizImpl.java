package com.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cxstock.biz.ziliao.dto.SpdwDTO;
import com.cxstock.dao.BaseDAO;
import com.pojo.Spdw;
import com.service.SpdwBiz;

@SuppressWarnings("unchecked")
@Transactional
@Service
public class SpdwBizImpl implements SpdwBiz {
	
	@Resource
	private BaseDAO baseDao;
	public void setBaseDao(BaseDAO baseDao) {
		this.baseDao = baseDao;
	}

	public List findAllSpdw() {
		return baseDao.listAll("Spdw");
	}

	/*
	 * 保存/修改商品
	 */
	public void saveOrUpdateSpdw(SpdwDTO dto) {
		Spdw spdw = new Spdw();
		if(dto.getDwid()!=null){
			spdw = (Spdw)baseDao.loadById(Spdw.class, dto.getDwid());
		}
		spdw.setDwname(dto.getDwname());
		baseDao.saveOrUpdate(spdw);
	}
	
	/*
	 * 删除商品
	 */
	public void deleteSpdw(Integer dwid) {
		baseDao.deleteById(Spdw.class, dwid);	
	}

}
