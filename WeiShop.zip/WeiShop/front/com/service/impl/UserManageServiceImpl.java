package com.service.impl;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.common.PageInfo;
import com.common.PageList;
import com.dao.IUserManageDao;
import com.entities.Tbuser;
import com.service.IUserManageService;

@Transactional
@Service("userManageService")
public class UserManageServiceImpl implements IUserManageService{
	@Resource
	private IUserManageDao userManageDao;	
	
	public PageList<Tbuser> findByPage(Tbuser userInfo,int page,int pageSize) {
		String hql = "FROM Tbuser as tb  where 1=1 ";
		
		if(userInfo != null) {
			if(StringUtils.isNotBlank(userInfo.getUserName())) {
				hql+= " and tb.userName like '%"+userInfo.getUserName()+"%' ";
			}
		}
		PageInfo pageinfo = new PageInfo();
		pageinfo.setPageIndex(page);
		pageinfo.setPageSize(pageSize);		
		PageList<Tbuser> pageList = new PageList<Tbuser>();
		pageList.setResultList(userManageDao.findPageByHQL(hql, pageinfo));
		pageList.setAllSize((int)pageinfo.getAllSize());
		pageList.setPageIndex(page);
		pageList.setPageSize(pageSize);
		return pageList;
	}
}