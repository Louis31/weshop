package com.service;

import java.util.List;

import com.cxstock.biz.ziliao.dto.SplbDTO;
import com.pojo.Position;

public interface PositionBiz {
	
	public Integer saveOrUpdatePosition(Position dto);
	
	
	public boolean deletePosition(Integer spid);

	
	@SuppressWarnings("unchecked")
	public List findPositionTree();

}
