package com.service;

import com.common.PageList;
import com.entities.Tbuser;
public interface IUserManageService{
	public PageList<Tbuser> findByPage(Tbuser userInfo,int page,int pageSize);
}
