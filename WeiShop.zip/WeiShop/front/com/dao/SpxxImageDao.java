package com.dao;

import com.base.IBaseDao;
import com.pojo.SpxxImage;

public interface SpxxImageDao extends IBaseDao<SpxxImage>{

}
