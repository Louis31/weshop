package com.dao;

import com.base.IBaseDao;
import com.pojo.Splb;

public interface ISplbDao extends IBaseDao<Splb>{

}
