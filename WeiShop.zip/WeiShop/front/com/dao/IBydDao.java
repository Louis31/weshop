package com.dao;

import com.base.IBaseDao;
import com.pojo.Byd;

public interface IBydDao extends IBaseDao<Byd>{

}
