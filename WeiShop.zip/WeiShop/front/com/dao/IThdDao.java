package com.dao;

import com.base.IBaseDao;
import com.pojo.Thd;

public interface IThdDao extends IBaseDao<Thd>{

}
