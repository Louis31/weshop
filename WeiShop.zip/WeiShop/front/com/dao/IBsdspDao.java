package com.dao;

import com.base.IBaseDao;
import com.pojo.Bsdsp;

public interface IBsdspDao extends IBaseDao<Bsdsp> {

}
