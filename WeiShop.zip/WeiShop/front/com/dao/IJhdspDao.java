package com.dao;

import com.base.IBaseDao;
import com.pojo.Jhdsp;

public interface IJhdspDao extends IBaseDao<Jhdsp> {

}
