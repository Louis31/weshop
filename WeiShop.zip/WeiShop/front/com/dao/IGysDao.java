package com.dao;

import com.base.IBaseDao;
import com.pojo.Gys;

public interface IGysDao  extends IBaseDao<Gys>{

}
