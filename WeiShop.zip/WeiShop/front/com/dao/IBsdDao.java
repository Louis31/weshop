package com.dao;

import com.base.IBaseDao;
import com.pojo.Bsd;

public interface IBsdDao extends IBaseDao<Bsd>{

}
