package com.dao;

import com.base.IBaseDao;
import com.pojo.Menu;

public interface IMenuDao extends IBaseDao<Menu>{

}
