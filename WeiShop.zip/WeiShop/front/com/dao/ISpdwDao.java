package com.dao;

import com.base.IBaseDao;
import com.pojo.Spdw;

public interface ISpdwDao extends IBaseDao<Spdw>{

}
