package com.dao;

import com.base.IBaseDao;
import com.pojo.Bydsp;

public interface IBydspDao extends IBaseDao<Bydsp> {

}
