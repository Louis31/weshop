package com.dao;

import com.base.IBaseDao;
import com.pojo.Spxx;

public interface ISpxxDao  extends IBaseDao<Spxx>{

}
