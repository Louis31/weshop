package com.dao.impl;

import org.springframework.stereotype.Repository;

import com.base.BaseDaoImpl;
import com.dao.IBydspDao;
import com.pojo.Bydsp;

@Repository
public class BydspDaoImpl extends BaseDaoImpl<Bydsp> implements IBydspDao {

}
