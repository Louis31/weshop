package com.dao.impl;

import org.springframework.stereotype.Repository;

import com.base.BaseDaoImpl;
import com.dao.SpxxImageDao;
import com.pojo.SpxxImage;

@Repository
public class SpxxImageDaoImpl extends BaseDaoImpl<SpxxImage> implements SpxxImageDao {

}
