package com.dao.impl;

import org.springframework.stereotype.Repository;

import com.base.BaseDaoImpl;
import com.dao.ISpxxDao;
import com.pojo.Spxx;

@Repository
public class SpxxDaoImpl extends BaseDaoImpl<Spxx> implements ISpxxDao{

}
