package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.IVusermenuDao;
import com.pojo.Vusermenu;

@Repository
public class VusermenuDaoImpl extends BaseDaoImpl<Vusermenu> implements IVusermenuDao {

}
