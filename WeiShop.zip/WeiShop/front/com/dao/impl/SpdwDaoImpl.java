package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.ISpdwDao;
import com.pojo.Spdw;

@Repository
public class SpdwDaoImpl extends BaseDaoImpl<Spdw> implements ISpdwDao{

}
