package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.IThdspDao;
import com.pojo.Thdsp;

@Repository
public class ThdspDaoImpl extends BaseDaoImpl<Thdsp> implements IThdspDao {

}
