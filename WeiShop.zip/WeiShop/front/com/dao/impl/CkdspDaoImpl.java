package com.dao.impl;

import org.springframework.stereotype.Repository;

import com.base.BaseDaoImpl;
import com.dao.ICkdspDao;
import com.pojo.Ckdsp;

@Repository
public class CkdspDaoImpl extends BaseDaoImpl<Ckdsp> implements ICkdspDao{

}
