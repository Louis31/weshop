package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.IJhdspDao;
import com.pojo.Jhdsp;

@Repository
public class JhdspDaoImpl extends BaseDaoImpl<Jhdsp> implements IJhdspDao{

}
