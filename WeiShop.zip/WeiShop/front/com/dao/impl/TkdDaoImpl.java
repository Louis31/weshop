package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.ITkdDao;
import com.pojo.Tkd;

@Repository
public class TkdDaoImpl extends BaseDaoImpl<Tkd> implements ITkdDao{

}
