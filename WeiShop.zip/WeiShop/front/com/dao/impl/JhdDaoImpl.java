package com.dao.impl;

import org.springframework.stereotype.Repository;

import com.base.BaseDaoImpl;
import com.dao.IJhdDao;
import com.pojo.Jhd;

@Repository
public class JhdDaoImpl extends BaseDaoImpl<Jhd> implements IJhdDao{

}
