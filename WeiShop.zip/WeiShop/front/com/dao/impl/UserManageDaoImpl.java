package com.dao.impl;

import org.springframework.stereotype.Repository;

import com.base.BaseDaoImpl;
import com.dao.IUserManageDao;
import com.entities.Tbuser;
@Repository("userManageDao")  
@SuppressWarnings("all") 
public class UserManageDaoImpl extends BaseDaoImpl<Tbuser> implements IUserManageDao{
}
