package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.ICkdDao;
import com.pojo.Ckd;

@Repository
public class CkdDaoImpl extends BaseDaoImpl<Ckd> implements ICkdDao {

}
