package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.IBydDao;
import com.pojo.Byd;

@Repository
public class BydDaoImpl extends BaseDaoImpl<Byd> implements IBydDao {

}
