package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.IGysDao;
import com.pojo.Gys;

@Repository
public class GysDaoImpl extends BaseDaoImpl<Gys> implements IGysDao {

}
