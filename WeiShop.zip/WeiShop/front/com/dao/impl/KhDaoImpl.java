package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.IKhDao;
import com.pojo.Kh;

@Repository
public class KhDaoImpl extends BaseDaoImpl<Kh> implements IKhDao{

}
