package com.dao.impl;

import org.springframework.stereotype.Repository;

import com.base.BaseDaoImpl;
import com.pojo.Bsdsp;

@Repository
public class BsdspDaoImpl extends BaseDaoImpl<Bsdsp>{

}
