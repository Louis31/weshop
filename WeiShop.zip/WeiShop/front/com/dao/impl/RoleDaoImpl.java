package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.IRoleDao;
import com.pojo.Role;

@Repository
public class RoleDaoImpl extends BaseDaoImpl<Role> implements IRoleDao{

}
