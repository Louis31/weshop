package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.ISplbDao;
import com.pojo.Splb;

@Repository
public class SplbDaoImpl extends BaseDaoImpl<Splb> implements ISplbDao {

}
