package com.dao.impl;

import org.springframework.stereotype.Repository;

import com.base.BaseDaoImpl;
import com.dao.IMenuDao;
import com.pojo.Menu;

@Repository
public class MenuDaoImpl extends BaseDaoImpl<Menu> implements IMenuDao{

}
