package com.dao.impl;

import org.springframework.stereotype.Repository;

import com.base.BaseDaoImpl;
import com.dao.IThdDao;
import com.pojo.Thd;

@Repository
public class ThdDaoImpl extends BaseDaoImpl<Thd> implements IThdDao {

}
