package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.ITkdspDao;
import com.pojo.Tkdsp;

@Repository
public class TkdspDaoImpl extends BaseDaoImpl<Tkdsp> implements ITkdspDao {

}
