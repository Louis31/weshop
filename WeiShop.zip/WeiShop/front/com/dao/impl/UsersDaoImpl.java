package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.IUsersDao;
import com.pojo.Users;

@Repository
public class UsersDaoImpl extends BaseDaoImpl<Users> implements IUsersDao{

}
