package com.dao.impl;

import org.springframework.stereotype.Repository;

import com.base.BaseDaoImpl;
import com.dao.IBsdDao;
import com.pojo.Bsd;

@Repository
public class BsdDaoImpl extends BaseDaoImpl<Bsd> implements IBsdDao{

}
