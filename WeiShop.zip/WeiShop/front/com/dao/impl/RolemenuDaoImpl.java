package com.dao.impl;

import org.springframework.stereotype.Repository;
import com.base.BaseDaoImpl;
import com.dao.IRolemenuDao;
import com.pojo.Rolemenu;

@Repository
public class RolemenuDaoImpl extends BaseDaoImpl<Rolemenu> implements IRolemenuDao {

}
