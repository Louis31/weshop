package com.dao;

import com.base.IBaseDao;
import com.entities.Tbuser;
public interface IUserManageDao extends IBaseDao<Tbuser>{
}
