package com.dao;

import com.base.IBaseDao;
import com.pojo.Ckd;

public interface ICkdDao extends IBaseDao<Ckd> {

}
