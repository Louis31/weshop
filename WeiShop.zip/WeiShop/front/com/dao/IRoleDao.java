package com.dao;

import com.base.IBaseDao;
import com.pojo.Role;

public interface IRoleDao extends IBaseDao<Role>{

}
