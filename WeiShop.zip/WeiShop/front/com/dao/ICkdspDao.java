package com.dao;

import com.base.IBaseDao;
import com.pojo.Ckdsp;

public interface ICkdspDao extends IBaseDao<Ckdsp>{

}
