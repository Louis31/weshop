package com.dao;

import com.base.IBaseDao;
import com.pojo.Rolemenu;

public interface IRolemenuDao extends IBaseDao<Rolemenu>{

}
