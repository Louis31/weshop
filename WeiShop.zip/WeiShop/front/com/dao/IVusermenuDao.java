package com.dao;

import com.base.IBaseDao;
import com.pojo.Vusermenu;

public interface IVusermenuDao extends IBaseDao<Vusermenu>{

}
