package com.dao;

import com.base.IBaseDao;
import com.pojo.Thdsp;

public interface IThdspDao extends IBaseDao<Thdsp> {

}
