package com.dao;

import com.base.IBaseDao;
import com.pojo.Jhd;

public interface IJhdDao extends IBaseDao<Jhd>{

}
