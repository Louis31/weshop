package com.dao;

import com.base.IBaseDao;
import com.pojo.Users;

public interface IUsersDao extends IBaseDao<Users>{

}
