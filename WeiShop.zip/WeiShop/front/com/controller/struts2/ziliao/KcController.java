package com.controller.struts2.ziliao;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.controller.struts2.BaseController;
import com.cxstock.biz.ziliao.dto.KcDTO;
import com.cxstock.utils.pubutil.Page;
import com.service.KcBiz;

@SuppressWarnings("serial")
@Controller
@RequestMapping("/kc")
public class KcController extends BaseController  {
	
	@Autowired
	private KcBiz kcBiz;
	
	/** 分页查询期初库存列表 */
	@RequestMapping(value="/findPageKc")
	@ResponseBody
	public String findPageKc(Page page) {
		try {
			kcBiz.findPageKc(page);
			return this.outPageString(page);
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}	

	/**
	 * 保存/修改期初库存
	 */
	@RequestMapping(value="/saveOrUpdateKc")
	@ResponseBody
	public String saveOrUpdateKc(KcDTO dto,String addupdate) {
		try {
			if(dto!=null&&dto.getSl()!=null&&dto.getCbj()!=null)
				dto.setZj(dto.getSl()*dto.getCbj());
			boolean bool = kcBiz.saveOrUpdateKc(dto);
			if("add".equals(addupdate)){
				if(bool){
					return "{success:true,message:'保存成功!'}";
				}else{
					return "{success:false,errors:'仓库中已存在该商品。'}";
				}
			}else{
				if(bool){
					return "{success:true,message:'修改成功!'}";
				}else{
					return "{success:false,errors:'该商品已经发生单据，不能修改。'}";
				}
			}
		} catch (Exception e) {
			 e.printStackTrace();
			 return this.outError();
		}
	}
    
	/**
	 * 删除期初库存
	 */
	@RequestMapping(value="/deleteKc")
	@ResponseBody
	public String deleteKc(String spid) {
		try {
			boolean bool = kcBiz.deleteKc(spid);
			if(bool){
				return "{success:true}";
			}else{
				return "{success:false,error:'该商品已经发生单据，不能删除。'}";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}
	
}
