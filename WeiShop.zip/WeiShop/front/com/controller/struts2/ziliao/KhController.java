package com.controller.struts2.ziliao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.controller.struts2.BaseController;
import com.cxstock.biz.ziliao.dto.KhDTO;
import com.cxstock.utils.pubutil.Page;
import com.service.KhBiz;

@SuppressWarnings("serial")
@Controller
@RequestMapping("/kh")
public class KhController extends BaseController  {
	
	@Autowired
	private KhBiz khBiz;
	
	/** 
	 * 分页查询客户列表 
	 */
	@RequestMapping(value="/findPageKh")
	@ResponseBody
	public String findPageKh(Integer start,Integer limit) {
		try {
			Page page = new Page();
			page.setStart(start);
			page.setLimit(limit);
			khBiz.findPageKh(page);
			return this.outPageString(page);
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}	

	/**
	 * 保存/修改客户
	 */
	@RequestMapping(value="/saveOrUpdateKh")
	@ResponseBody
	public String saveOrUpdateKh(KhDTO dto) {
		try {
			khBiz.saveOrUpdateKh(dto);
			if(dto!=null&&dto.getKhid()!=null){
				return "{success:true,message:'修改成功!'}";
			}else{
				return "{success:true,message:'保存成功!'}";
			}
		} catch (Exception e) {
			 e.printStackTrace();
			 return this.outError();
		}
	}
    
	/**
	 * 删除客户
	 */
	@RequestMapping(value="/deleteKh")
	@ResponseBody
	public String deleteKh(Integer khid) {
		try {
			khBiz.deleteKh(khid);
			return "{success:true}";
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}
	
	/** 
	 * 客户下拉列表
	 */
	@RequestMapping(value="/findKhComb")
	@ResponseBody
	public String findKhComb() {
		try {
			return this.outListString(khBiz.findKhComb());
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}

}
