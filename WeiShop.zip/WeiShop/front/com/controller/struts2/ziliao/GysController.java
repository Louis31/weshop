package com.controller.struts2.ziliao;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.controller.struts2.BaseController;
import com.cxstock.biz.ziliao.dto.GysDTO;
import com.cxstock.utils.pubutil.Page;
import com.service.GysBiz;

@SuppressWarnings("serial")
@Controller
@RequestMapping("/gys")
public class GysController extends BaseController  {
	
	@Autowired
	private GysBiz gysBiz;
	
	
	/** 
	 * 分页查询供应商列表 
	 */
	@RequestMapping(value="/findPageGys")
	@ResponseBody
	public String findPageGys(Page page) {
		try {
			gysBiz.findPageGys(page);
			return this.outPageString(page);
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}	

	/**
	 * 保存/修改供应商
	 */
	@RequestMapping(value="/saveOrUpdateGys")
	@ResponseBody
	public String saveOrUpdateGys(GysDTO dto) {
		try {
			//GysDTO dto = new GysDTO(gysid,name,lxren,lxtel,address,bz);
			gysBiz.saveOrUpdateGys(dto);
			if(dto!=null&&dto.getGysid()!=null){
				return "{success:true,message:'修改成功!'}";
			}else{
				return "{success:true,message:'保存成功!'}";
			}
		} catch (Exception e) {
			 return this.outError();
		}
	}
    
	/**
	 * 删除供应商
	 */
	@RequestMapping(value="/deleteGys")
	@ResponseBody
	public String deleteGys(Integer gysid) {
		try {
			gysBiz.deleteGys(gysid);
			return "{success:true}";
		} catch (Exception e) {
			return this.outError();
		}
	}
	
	/** 
	 * 供应商下拉列表
	 */
	@RequestMapping(value="/findGysComb")
	@ResponseBody
	public String findGysComb() {
		try {
			return this.outListString(gysBiz.findGysComb());
		} catch (Exception e) {
			return this.outError();
		}
	}
}
