package com.controller.struts2.ziliao;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.controller.struts2.BaseController;
import com.cxstock.biz.ziliao.dto.SpdwDTO;
import com.service.SpdwBiz;

@SuppressWarnings("serial")
@Controller
@RequestMapping("/spdw")
public class SpdwController extends BaseController {
	
	@Autowired
	private SpdwBiz spdwBiz;
	
//	private Integer dwid;
//	private String dwname;
	
	/** 
	 * 单位列表 
	 */
	@RequestMapping(value="/findAllSpdw")
	@ResponseBody
	public String findAllSpdw() {
		try {
			return this.outListString(spdwBiz.findAllSpdw());
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}

	/**
	 * 保存/修改单位
	 */
	@RequestMapping(value="/saveOrUpdateSpdw")
	@ResponseBody
	public String saveOrUpdateSpdw(Integer dwid,String dwname) {
		try {
			SpdwDTO dto = new SpdwDTO(dwid,dwname);
			spdwBiz.saveOrUpdateSpdw(dto);
			if(dwid==null){
				return "{success:true,message:'保存成功!'}";
			}else{
				return "{success:true,message:'修改成功!'}";
			}
		} catch (Exception e) {
			 e.printStackTrace();
			 this.outError();
		}
		return null;
	}
    
	/**
	 * 删除单位
	 */
	@RequestMapping(value="/deleteSpdw")
	@ResponseBody
	public String deleteSpdw(Integer dwid) {
		try {
			spdwBiz.deleteSpdw(dwid);
			return "{success:true}";
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}

}
