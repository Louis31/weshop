package com.controller.struts2.ziliao;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.controller.struts2.BaseController;
import com.cxstock.biz.ziliao.dto.SplbDTO;
import com.service.SplbBiz;

@SuppressWarnings("serial")
@Controller
@RequestMapping("/splb")
public class SplbController extends BaseController  {
	
	@Autowired
	private SplbBiz splbBiz;
	
//	private Integer lbid;
//	private String lbname;
//	private Integer pid;
	
	/** 
	 * 商品类别树
	 */
	@RequestMapping(value="/findSplbTree")
	@ResponseBody
	public String findSplbTree() {
		try {
			return this.outTreeJsonList(splbBiz.findSplbTree());
		} catch (Exception e) {
			return this.outError();
		}
	}	

	/**
	 * 保存/修改商品类别
	 */
	@RequestMapping(value="/saveOrUpdateSplb")
	@ResponseBody
	public String saveOrUpdateSplb(Integer lbid,String lbname,Integer pid) {
		try {
			SplbDTO dto = new SplbDTO(lbid,lbname,pid);
			int id = splbBiz.saveOrUpdateSplb(dto);
			if(lbid==null){
				return "{success:true,message:"+id+"}";
			}else{
				return "{success:true,message:'修改成功!'}";
			}
		} catch (Exception e) {
			 return this.outError();
		}
	}
    
	/**
	 * 删除商品类别
	 */
	@RequestMapping(value="/deleteSplb")
	@ResponseBody
	public String deleteSplb(Integer lbid) {
		try {
			if(splbBiz.deleteSplb(lbid)){
				return "true";
			}else{
				return "false";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}

}
