package com.controller.struts2.power;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.controller.struts2.BaseController;
import com.cxstock.action.BaseAction;
import com.cxstock.utils.system.DataCopy;

@SuppressWarnings("serial")
@Controller
@RequestMapping("/dataCopy")
public class DataCopyController extends BaseController  {
	
//	private String datapath;
//	private String datafile;
//	private String delstate;
	
	/**
	 * 备份数据库
	 */
	@RequestMapping(value="/backup")
	@ResponseBody
	public String backup(String datapath){
		try {
			SimpleDateFormat bartDateFormat = new SimpleDateFormat("yyyy_MM_dd_hh_mm");
			String d = bartDateFormat.format(new Date());
			DataCopy.backup(datapath+"data_"+d+".sql");
			return "true";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "false";
	}

	/**
	 * 恢复数据库
	 */
	@RequestMapping(value="/load")
	@ResponseBody
	public String load(String datafile) {
		try {
			SimpleDateFormat bartDateFormat = new SimpleDateFormat("yyyy_MM_dd_hh_mm");
			String d = bartDateFormat.format(new Date());
			DataCopy.backup("D:\\MyStockData\\old_"+d+".sql");
			DataCopy.load(datafile);
			return "true";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "false";
	}
	
	/**
	 * 系统初始化（删除所有营业数据）
	 */
	@RequestMapping(value="/delete")
	@ResponseBody
	public String delete(String delstate){
		try {
			SimpleDateFormat bartDateFormat = new SimpleDateFormat("yyyy_MM_dd_hh_mm");
			String d = bartDateFormat.format(new Date());
			DataCopy.backup("D:\\MyStockData\\del_"+d+".sql");
			DataCopy.delete(delstate);
			return "true";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "false";
	}
}
