package com.controller.struts2.tongji;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.controller.struts2.BaseController;
import com.service.TongjiBiz;

@SuppressWarnings("serial")
@Controller
@RequestMapping("/tongji")
public class TongjiController extends BaseController  {
	
	@Autowired
	private TongjiBiz tongjiBiz;

	/**
	 * 供应商统计
	 */
	@RequestMapping(value="/findGysTj")
	@ResponseBody
	public String findGysTj(String startdate,String enddate,String gysid,String jystate){
		try {
			StringBuffer wheres = new StringBuffer();
			if(startdate!=null&&enddate!=null){
				wheres.append(" and t.riqi between '");
				wheres.append(startdate);
				wheres.append("' and '");
				wheres.append(enddate);
				wheres.append("'");
			}
			if(gysid!=null&&!"".equals(gysid)){
				wheres.append(" and t.gysid=");
				wheres.append(gysid);
			}
			if(jystate!=null&&!"".equals(jystate)){
				wheres.append(" and t.jystate=");
				wheres.append(jystate);
			}
			return this.outListString(tongjiBiz.findGysTj(wheres.toString()));
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}
	
	/**
	 * 客户统计
	 */
	@RequestMapping(value="/findKhTj")
	@ResponseBody
	public String findKhTj(String startdate,String enddate,String khid,String jystate){
		try {
			StringBuffer wheres = new StringBuffer();
			if(startdate!=null&&enddate!=null){
				wheres.append(" and t.riqi between '");
				wheres.append(startdate);
				wheres.append("' and '");
				wheres.append(enddate);
				wheres.append("'");
			}
			if(khid!=null&&!"".equals(khid)){
				wheres.append(" and t.khid=");
				wheres.append(khid);
			}
			if(jystate!=null&&!"".equals(jystate)){
				wheres.append(" and t.jystate=");
				wheres.append(jystate);
			}
			this.outListString(tongjiBiz.findKhTj(wheres.toString()));
		} catch (Exception e) {
			e.printStackTrace();
			this.outError();
		}
		return null;
	}
	
	/**
	 * 商品采购统计
	 */
	@RequestMapping(value="/findSpcgTj")
	@ResponseBody
	public String findSpcgTj(String startdate,String enddate,String lbid,String search){
		try {
			StringBuffer wheres = new StringBuffer("where 1=1");
			if(startdate!=null&&enddate!=null){
				wheres.append(" and t.jhd.riqi between '");
				wheres.append(startdate);
				wheres.append("' and '");
				wheres.append(enddate);
				wheres.append("'");
			}
			if(lbid!=null&&!"".equals(lbid)&&!"0".equals(lbid)){
				wheres.append(" and t.lbid=");
				wheres.append(lbid);
			}
			if(search!=null&&!"".equals(search)){
				wheres.append(" and (t.spid like '%");
				wheres.append(search);
				wheres.append("%' or t.spname like '%");
				wheres.append(search);
				wheres.append("%')");
			}
			return this.outListString(tongjiBiz.findSpcgTj(wheres.toString()));
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}
	
	/**
	 * 商品销售统计
	 */
	@RequestMapping(value="/findSpxstj")
	@ResponseBody
	public String findSpxstj(String startdate,String enddate,String lbid,String search){
		try {
			StringBuffer wheres = new StringBuffer("where 1=1");
			if(startdate!=null&&enddate!=null){
				wheres.append(" and t.ckd.riqi between '");
				wheres.append(startdate);
				wheres.append("' and '");
				wheres.append(enddate);
				wheres.append("'");
			}
			if(lbid!=null&&!"".equals(lbid)&&!"0".equals(lbid)){
				wheres.append(" and t.lbid=");
				wheres.append(lbid);
			}
			if(search!=null&&!"".equals(search)){
				wheres.append(" and (t.spid like '%");
				wheres.append(search);
				wheres.append("%' or t.spname like '%");
				wheres.append(search);
				wheres.append("%')");
			}
			return this.outListString(tongjiBiz.findSpxstj(wheres.toString()));
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}
	
	/**
	 * 按日统计分析
	 */
	@RequestMapping(value="/findTjfxRi")
	@ResponseBody
	public String findTjfxRi(String startdate,String enddate,String search){
		try {
			StringBuffer wheres = new StringBuffer();
			if(startdate!=null&&enddate!=null){
				wheres.append(" and t.riqi between '");
				wheres.append(startdate);
				wheres.append("' and '");
				wheres.append(enddate);
				wheres.append("' group by t.riqi");
			}
			
			String[] s = startdate.split("-");
			String[] e = enddate.split("-");
			Calendar cs = Calendar.getInstance();
			Calendar ce = Calendar.getInstance();
			cs.set(Integer.parseInt(s[0]),Integer.parseInt(s[1])-1,Integer.parseInt(s[2]));
			ce.set(Integer.parseInt(e[0]),Integer.parseInt(e[1])-1,Integer.parseInt(e[2])+1);
			List<String> dates = new ArrayList<String>();
			while (cs.before(ce)) {
				String year = String.valueOf(cs.get(Calendar.YEAR));
				String month = String.valueOf(cs.get(Calendar.MONTH) + 1);
				String day = String.valueOf(cs.get(Calendar.DAY_OF_MONTH));
				if(month.length()==1)
					month = "0"+month;
				if(day.length()==1)
					day = "0"+day;
				String date = year + "-" + month + "-" + day;
				dates.add(date);
				cs.add(5, 1);
			}
			return (tongjiBiz.findTjfxRi(wheres.toString(),dates));
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}
	
	/**
	 * 按月统计分析
	 */
	@RequestMapping(value="/findTjfxYue")
	@ResponseBody
	public String findTjfxYue(String startdate,String enddate,String search){
		try {
			StringBuffer wheres = new StringBuffer();
			if(startdate!=null&&enddate!=null){
				wheres.append(" and t.riqi between '");
				wheres.append(startdate);
				wheres.append("' and '");
				wheres.append(enddate);
				wheres.append("' group by DATE_FORMAT(t.riqi,'%Y-%m')");
			}
			
			String[] s = startdate.split("-");
			String[] e = enddate.split("-");
			Calendar cs = Calendar.getInstance();
			Calendar ce = Calendar.getInstance();
			cs.set(Integer.parseInt(s[0]),Integer.parseInt(s[1])-1,1);
			ce.set(Integer.parseInt(e[0]),Integer.parseInt(e[1]),1);
			List<String> dates = new ArrayList<String>();
			while (cs.before(ce)) {
				String year = String.valueOf(cs.get(Calendar.YEAR));
				String month = String.valueOf(cs.get(Calendar.MONTH) + 1);
				if(month.length()==1)
					month = "0"+month;
				String date = year + "-" + month;
				dates.add(date);
				cs.add(2, 1);
			}
			return tongjiBiz.findTjfxYue(wheres.toString(),dates);
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}
	
}
