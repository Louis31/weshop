package com.controller.struts2.kucun;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.controller.struts2.BaseController;
import com.service.SearchBiz;

@Controller
@RequestMapping("/search")
public class SearchController extends BaseController  {
	
	@Autowired
	private SearchBiz searchBiz;
	
//	private Integer kfid;
//	private Integer lbid;
//	private String search;
	
	/**
	 * 库存查询
	 */
	@RequestMapping(value="/findKcByParams")
	@ResponseBody
	public String findKcByParams(Integer kfid,Integer lbid,String search){
		try {
			return this.outListString(searchBiz.findKcByParams(kfid,lbid,search));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this.outError();
	}
	
	/**
	 * 库存报警
	 * @param searchBiz
	 */
	@RequestMapping(value="/findBaoJingSpxx")
	@ResponseBody
	public String findBaoJingSpxx(){
		try {
			return this.outListString(searchBiz.findBaoJingSpxx());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this.outError();
	}

}
