package com.controller.struts2.kucun;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.controller.struts2.BaseController;
import com.pojo.Bsd;
import com.pojo.Byd;
import com.service.BsyBiz;

@SuppressWarnings("serial")
@Controller
@RequestMapping("/bsy")
public class BsyController extends BaseController  {
	@Autowired
	private BsyBiz bsyBiz;
	
	
	/**
	 * 生成单据编号
	 */
	@RequestMapping(value="/getDjCode")
	@ResponseBody
	public String getDjCode(String tab,String ymd){
		try {
			String code = bsyBiz.getDjCode(tab,ymd);
			return code;
		} catch (Exception e) {
			e.printStackTrace();		
		}
		return this.outError();
	}
	
	/**
	 * 保存/修改报损单
	 */
	@RequestMapping(value="/saveOrUpdateBsd")
	@ResponseBody
	public String saveOrUpdateBsd(Bsd pojo,String djsps) {
		try {
			//Bsd pojo = new Bsd();
//			pojo.setDjid(djid);
//			pojo.setRiqi(riqi);
		//	pojo.setUserid(this.getUserDTO().getUserid());
		//	pojo.setUsername(this.getUserDTO().getUsername());
		//	pojo.setBz(bz);
			bsyBiz.saveOrUpdateBsd(pojo,djsps);
			return "{success:true}";
		} catch (Exception e) {
			 e.printStackTrace();
			 this.outError();
		}
		return null;
	}
	
	/**
	 * 保存/修改报溢单
	 */
	@RequestMapping(value="/saveOrUpdateByd")
	@ResponseBody
	public String saveOrUpdateByd(Byd pojo,String djsps) {
		try {
//			Byd pojo = new Byd();
//			pojo.setDjid(djid);
//			pojo.setRiqi(riqi);
//			//pojo.setUserid(this.getUserDTO().getUserid());
//			//pojo.setUsername(this.getUserDTO().getUsername());
//			pojo.setBz(bz);
			bsyBiz.saveOrUpdateByd(pojo,djsps);
			return"{success:true}";
		} catch (Exception e) {
			 e.printStackTrace();
			 this.outError();
		}
		return null;
	}
	
    
	/**
	 * 删除报损单
	 */
	@RequestMapping(value="/deleteJhd")
	@ResponseBody
	public String deleteJhd(String kcid) {
		try {
			//jhService.deleteJhd(kcid);
			return "{success:true}";
		} catch (Exception e) {
			e.printStackTrace();
			this.outError();
		}
		return null;
	}
	
	/**
	 * 按条件查询单据
	 */
	@RequestMapping(value="/findDjByParams")
	@ResponseBody
	public String findDjByParams(String startdate,String enddate,
			String search,String djid,String jystate,String tab){
		try {
			StringBuffer wheres = new StringBuffer(" where 1=1");
			if(startdate!=null&&enddate!=null){
				wheres.append(" and t.riqi between '");
				wheres.append(startdate);
				wheres.append("' and '");
				wheres.append(enddate);
				wheres.append("'");
			}
			if(search!=null&&!"".equals(search)){
				wheres.append(" and (t.djid like '%");
				wheres.append(search);
				wheres.append("%'");
				wheres.append(" or t.gysname like '%");
				wheres.append(search);
				wheres.append("%')");
			}else if(djid!=null){
				wheres.append(" and t.djid='");
				wheres.append(djid);
				wheres.append("'");
			}
			startdate=null;
			enddate=null;
			search=null;
			djid=null;
			return this.outListString(bsyBiz.findDjByParams(tab,wheres.toString()));
		} catch (Exception e) {
			e.printStackTrace();			
		}
		return this.outError();
	}
}
