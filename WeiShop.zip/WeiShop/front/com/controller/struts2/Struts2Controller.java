package com.controller.struts2;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.common.WebGlobal;


@Controller
@RequestMapping("/struts2")
public class Struts2Controller {
       
	  @RequestMapping("/{modul}/{page}")
	  public String turnpage(@PathVariable(value = "modul") String modul,@PathVariable(value = "page") String page) {
	        return WebGlobal.getAdminViewPath()+"/"+modul+"/"+page;
	  }
}
