package com.controller.struts2;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JsonConfig;
import net.sf.json.util.PropertyFilter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pojo.Ckd;
import com.pojo.Tkd;
import com.service.XsService;


@Controller
@RequestMapping("/xs")	
public class XsController extends BaseController{
	
	@Autowired
	private XsService xsBiz;
	/**
	 * 生成单据编号
	 */
	@RequestMapping(value="/getDjCode")
	@ResponseBody
	public String getDjCode(String tab,String ymd){
		try {
			String code = xsBiz.getDjCode(tab,ymd);
			return code;
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return "{success:false,errors:'操作失败！'}";
	}
	
	/**
	 * 保存/修改销售单
	 */
	@RequestMapping(value="/saveOrUpdateCkd")
	@ResponseBody
	public String saveOrUpdateCkd(Ckd pojo,String djsps) {
		try {
//			Ckd pojo = new Ckd();
//			pojo.setDjid(djid);
//			pojo.setKhid(khid);
//			pojo.setKhname(khname);
//			pojo.setYfje(yfje);
//			pojo.setSfje(sfje);
//			pojo.setCbje(cbje);
//			pojo.setJystate(jystate);
//			pojo.setRiqi(riqi);
//			//pojo.setUserid(this.getUserDTO().getUserid());
//			//pojo.setUsername(this.getUserDTO().getUsername());
//			pojo.setBz(bz);
			xsBiz.saveOrUpdateCkd(pojo,djsps);
			return "{success:true}";
		} catch (Exception e) {
			 e.printStackTrace();
		}
		return "{success:false,errors:'操作失败！'}";
	}
	
	/**
	 * 保存/修改退货单
	 */
	@RequestMapping(value="/saveOrUpdateTkd")
	@ResponseBody
	public String saveOrUpdateTkd(Tkd pojo,String djsps) {
		try {
			xsBiz.saveOrUpdateTkd(pojo,djsps);
			return "{success:true}";
		} catch (Exception e) {
			 e.printStackTrace();
			
		}
		return "{success:false,errors:'操作失败！'}";
	}
	
    
	/**
	 * 删除销售单
	 */
	@RequestMapping(value="/deleteCkd")
	@ResponseBody
	public String deleteCkd(String djid) {
		try {
			xsBiz.deleteCkd(djid);
			return "{success:true}";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "{success:false,errors:'操作失败！'}";
	}
	
	/**
	 * 删除退货单
	 */
	@RequestMapping(value="/deleteTkd")
	@ResponseBody
	public String deleteTkd(String djid) {
		try {
			xsBiz.deleteTkd(djid);
			return "{success:true}";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "{success:false,errors:'操作失败！'}";
	}
	
	/**
	 * 按条件查询单据
	 */
	@RequestMapping(value="/findDjByParams")
	@ResponseBody
	public String findDjByParams(String startdate,String enddate,
			String search,String djid,String jystate,String tab){
		Map<String, Object> resultMap=new HashMap<String, Object>();
		try {
			StringBuffer wheres = new StringBuffer(" where 1=1");
			if(startdate!=null&&enddate!=null){
				wheres.append(" and t.riqi between '");
				wheres.append(startdate);
				wheres.append("' and '");
				wheres.append(enddate);
				wheres.append("'");
			}
			if(search!=null&&!"".equals(search)){
				wheres.append(" and (t.djid like '%");
				wheres.append(search);
				wheres.append("%'");
				wheres.append(" or t.gysname like '%");
				wheres.append(search);
				wheres.append("%')");
			}else if(djid!=null){
				wheres.append(" and t.djid='");
				wheres.append(djid);
				wheres.append("'");
			}
			if(jystate!=null&&!"".equals(jystate)){
				wheres.append(" and t.jystate=");
				wheres.append(jystate);
			}
	        
			
			return this.outListString(xsBiz.findDjByParams(tab,wheres.toString()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "{success:false,errors:'操作失败！'}";
	}
	
	/**
	 * 查询单据商品
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/findDjspByParams")
	@ResponseBody
	public String findDjspByParams(String djid,String info,String tab){
		try {
			StringBuffer wheres = new StringBuffer(" where 1=1");
			if(djid!=null){
				wheres.append(" and t."+info+".djid='");
				wheres.append(djid);
				wheres.append("'");
			}
			List list = xsBiz.findDjByParams(tab,wheres.toString());
			JSONArray jsonArray = new JSONArray();
			if(list.size()>0){
				JsonConfig config = new JsonConfig();
				// 过滤相关的属性即可
				config.setJsonPropertyFilter(new PropertyFilter() {
					public boolean apply(Object source, String name, Object value) {
						if (name.equals(info)) {
							return true;
						}
						return false;
					}
				});
				jsonArray = JSONArray.fromObject(list,config);
			}
			String jsonString = "{total:" + list.size() + ",root:"+ jsonArray.toString() + "}";
			return jsonString;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "{success:false,errors:'操作失败！'}";
	}
}
