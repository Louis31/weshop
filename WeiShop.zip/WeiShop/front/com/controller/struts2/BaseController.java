package com.controller.struts2;

import java.util.List;

import com.cxstock.utils.pubutil.Page;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class BaseController {
	public String outListString(List list) {
			try {
				JSONArray jsonArray = new JSONArray();
				if (list.size() > 0) {
					jsonArray = JSONArray.fromObject(list);
				}
				String jsonString = "{total:" + list.size() + ",root:"
						+ jsonArray.toString() + "}";
				return jsonString;
	
			} catch (Exception e) {
				e.printStackTrace();
			}
			return "{success:false,errors:'操作失败！'}";
		}
	
	public String JsonList(List list) {
		try {
			JSONArray jsonArray = new JSONArray();
			if (list.size() > 0) {
				jsonArray = JSONArray.fromObject(list);
			}
			String jsonString = "{total:" + list.size() + ",root:"
					+ jsonArray.toString() + "}";
			return jsonString;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "{success:false,errors:'操作失败！'}";
	}
	
	public String outError() {
		return "{success:false,errors:'操作失败！'}";
	}
	
	public String outObjectString(Object obj) {
		JSONObject josnobj = new JSONObject();
		if (obj != null) {
			josnobj = JSONObject.fromObject(obj);
		}
		String jsonString = "{success:true,data:" + josnobj.toString() + "}";
		return jsonString;
	}

	public String outObjString(Object obj) {
		JSONArray jsonArray = new JSONArray();
		if (obj != null) {
			jsonArray = JSONArray.fromObject(obj);
		}
		String jsonString = "{success:true,data:" + jsonArray.toString() + "}";
		return jsonString;
	}

	public String outPageString(Page page) {

		JSONArray jsonArray = new JSONArray();
		if (page.getRoot().size() > 0) {
			jsonArray = JSONArray.fromObject(page.getRoot());
		}
		String jsonString = "{total:" + page.getTotal() + ",root:"
				+ jsonArray.toString() + "}";
		return jsonString;
	}
	
	@SuppressWarnings("unchecked")
	public String outTreeJsonList(List list){
		JSONArray jsonArray = new JSONArray();
		if (list.size() > 0) {
			jsonArray = JSONArray.fromObject(list);
		}
		return jsonArray.toString();
	}
}

