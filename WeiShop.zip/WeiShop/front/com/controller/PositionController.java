package com.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.controller.struts2.BaseController;
import com.cxstock.biz.ziliao.dto.SplbDTO;
import com.pojo.Position;
import com.service.PositionBiz;
import com.service.SplbBiz;

@SuppressWarnings("serial")
@Controller
@RequestMapping("/position")
public class PositionController extends BaseController  {
	
	@Autowired
	private PositionBiz splbBiz;
	
//	private Integer lbid;
//	private String lbname;
//	private Integer pid;
	
	/** 
	 * 商品类别树
	 */
	@RequestMapping(value="/findPositionTree")
	@ResponseBody
	public String findPositionTree() {
		try {
			return this.outTreeJsonList(splbBiz.findPositionTree());
		} catch (Exception e) {
			return this.outError();
		}
	}	

	/**
	 * 保存/修改商品类别
	 */
	@RequestMapping(value="/saveOrUpdatePosition")
	@ResponseBody
	public String saveOrUpdatePosition(Position position) {
		try {
		
			int id = splbBiz.saveOrUpdatePosition(position);
			if(position.getSpid()==null){
				return "{success:true,message:"+id+"}";
			}else{
				return "{success:true,message:'修改成功!'}";
			}
		} catch (Exception e) {
			 return this.outError();
		}
	}
    
	/**
	 * 删除商品类别
	 */
	@RequestMapping(value="/deletePosition")
	@ResponseBody
	public String deletePosition(Integer spid) {
		try {
			if(splbBiz.deletePosition(spid)){
				return "true";
			}else{
				return "false";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return this.outError();
		}
	}

}
