package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.common.WebGlobal;

@RequestMapping("/admin")	
@Controller
public class AdminController {
    
	@RequestMapping("")
	  public String turnpage() {
	        return WebGlobal.getAdminViewPath()+"/main/index";
	  }
}
