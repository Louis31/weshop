package com.controller;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class JHJsonEntity {
	private String djid;
	private Integer gysid;
	private String gysname;
	@DateTimeFormat( pattern = "yyyy-MM-dd" )
	private Date riqi;
	private Double yfje;
	private Double sfje;
	private String jystate;
	private String bz;
	private Integer sp_id;
	private String sp_name;
	
	private String djsps;
   public JHJsonEntity(){}
	public String getDjid() {
		return djid;
	}

	public void setDjid(String djid) {
		this.djid = djid;
	}

	public Integer getGysid() {
		return gysid;
	}

	public void setGysid(Integer gysid) {
		this.gysid = gysid;
	}

	public String getGysname() {
		return gysname;
	}

	public void setGysname(String gysname) {
		this.gysname = gysname;
	}

	public Date getRiqi() {
		return riqi;
	}
	public void setRiqi(Date riqi) {
		this.riqi = riqi;
	}
	public Integer getSp_id() {
		return sp_id;
	}
	public void setSp_id(Integer sp_id) {
		this.sp_id = sp_id;
	}
	public String getSp_name() {
		return sp_name;
	}
	public void setSp_name(String sp_name) {
		this.sp_name = sp_name;
	}
	public Double getYfje() {
		return yfje;
	}

	public void setYfje(Double yfje) {
		this.yfje = yfje;
	}

	public Double getSfje() {
		return sfje;
	}

	public void setSfje(Double sfje) {
		this.sfje = sfje;
	}

	public String getJystate() {
		return jystate;
	}

	public void setJystate(String jystate) {
		this.jystate = jystate;
	}

	public String getBz() {
		return bz;
	}

	public void setBz(String bz) {
		this.bz = bz;
	}

	public String getDjsps() {
		return djsps;
	}

	public void setDjsps(String djsps) {
		this.djsps = djsps;
	}
}
