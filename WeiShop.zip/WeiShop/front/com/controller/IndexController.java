package com.controller;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONObject;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


/**
 * @ClassName: IndexController
 * @Description: 首页Controller
 * @author AiYangCheng
 * @date 2014年7月28日 上午11:55:22
 *
 */
@Controller("/wostar2")
@RequestMapping("/index")
public class IndexController {
    
//    private static  Log logger = LogFactory.getLog(IndexController.class);
//    
//    private static int pageSize = 5; // 每页面记录数
//    private static int pageSize9 = 9; // 每页面记录数
//    private static int pageSize10 = 10; // 每页面记录数
//    private static int pageSize40 = 40; // 每页面记录数
//    private static int pageSize4 = 4; // 每页面记录数
//    
////    @Autowired
////    private IFansInfoService fansInfoService;
////    
////    @Autowired
////    private BannerService bannerService;
////    
////    @Autowired
////    private IWechatInterfaceService wechatInterfaceService;
////    
////    @Autowired
////    private SongService songService;
////    
////    @Autowired
////    private SingerService singerService;
////    
////    @Autowired
////    private MusicboxService musicboxService;
////    
////    @Autowired
////    private MobileUtil mobileUtil;
////    
////    @Autowired
////    private UnicomUserService unicomUserService;
////    
////    private PropertyContext propertyContext = PropertyContext.
////            PropertyContextFactory("weChat.properties");
//
//    
//    /**
//     * @Title: toIndex
//     * @Description: 新版30强首页
//     * @param code
//     * @param state OAuto授权后返回愿意参数（授权后重定向地址）,参数之间“_”分割
//     * @param session
//     * @return String 
//     */
//    @RequestMapping("toNewIndex")
//    public String toNewIndex(@RequestParam(required = false) String code, 
//            @RequestParam(required = false) Integer page,
//            @RequestParam(required = false) String redirectUrl,
//            @RequestParam(required = false) String state,
//            @RequestParam(required = false) String unikey,
//            HttpSession session, Model model,HttpServletRequest request) {
//        if(state!=null){
//            redirectUrl=state;
//        }
//        if(null == page) {
//            page = 1;
//        }
//        FansInfo fansInfo = (FansInfo)session.getAttribute("fansInfo");
////        String openId = "o0D8PuEk2Ock3jZ_UIbCEs8RMbW4";
////        String openId = "ogvWijhsGhY18tjCHs_MbFml6LqI";
////        String openId = "o0D8PuEk2Ock3jZ_UIbCEs8RMbW4";
//        String openId = null;
//        if(StringUtils.isBlank(ObjectUtils.toString(fansInfo))) {
//            String uuidStr = StringUtil.getUUidStr();
//            String suffix = "/index/toNewIndex.do?unikey="+uuidStr;
//            if(StringUtils.isNotBlank(redirectUrl)) {
//                suffix = "/index/toNewIndex.do?unikey=" + uuidStr + 
//                        "&redirectUrl=" + redirectUrl;
//                session.setAttribute("redirectUrl", redirectUrl);
//            }
//            logger.info("<|>wostar2<|>网页授权<|>code is>>>>>>>>" + code);
//            if (StringUtils.isBlank(code)) {
//            return "redirect:" + OAuth2Util.getCodeWithSuffix(suffix);
//            }
//            openId = OAuth2Util.getOpenId(code);
//            logger.info("<|>wostar2<|>网页授权<|>openId is>>>>>>>>" + openId);
//            if (StringUtils.isBlank(openId)) {
//            return "redirect:" + OAuth2Util.getCodeWithSuffix(suffix);
//            }
//        }else {
//            openId = fansInfo.getUopenid();
//        }
//        FansInfo wechatFansInfo = null;
//        try {
//            // 从微信接口获取粉丝信息
//            String appId = propertyContext.get("appid");
//            String appSecret = propertyContext.get("secret");
//            wechatFansInfo = wechatInterfaceService.getFansInfo(openId, appId, appSecret);
//        } catch (Exception e) {
//            logger.info("<|>get fansInfo fail from weixin", e);
//        }
//        // 从数据库获取粉丝信息
//        fansInfo = fansInfoService.findByOpenId(openId);
//        if(fansInfo == null) { // 数据库找不到粉丝信息，则保存微信接口获取的粉丝信息
//            if(wechatFansInfo != null) {
//                fansInfo = wechatFansInfo;
//            } else { 
//                fansInfo = new FansInfo();
//                fansInfo.setUopenid(openId);
//                fansInfo.setUsubscribe(0);
//            }
//            try {
//                fansInfo = fansInfoService.save(fansInfo);
//            } catch (ApplicationException e) {
//                logger.error("<|>login controller<|>save fansinfo fail<|>openId >>" + openId, e);
//                fansInfo = fansInfoService.findByOpenId(openId);
//            }
//        } else if(wechatFansInfo != null) { // 更新粉丝信息
//            fansInfo.setUsubscribe(wechatFansInfo.getUsubscribe());
//            fansInfo.setUopenid(wechatFansInfo.getUopenid());
//            fansInfo.setUnickname(wechatFansInfo.getUnickname());
//            fansInfo.setUsex(wechatFansInfo.getUsex());
//            fansInfo.setUlanguage(wechatFansInfo.getUlanguage());
//            fansInfo.setUcity(wechatFansInfo.getUcity());
//            fansInfo.setUprovince(wechatFansInfo.getUprovince());
//            fansInfo.setUcountry(wechatFansInfo.getUcountry());
//            fansInfo.setUheadimgurl(wechatFansInfo.getUheadimgurl());
//            fansInfo.setUsubscribeTime(wechatFansInfo.getUsubscribeTime());
//            
//            boolean isSuccess = false;
//            try {
//                isSuccess = fansInfoService.update(fansInfo);
//            } catch (ApplicationException e) {
//                logger.error("<|>login controller<|>update fansinfo fail<|>openId >>" + openId, e);
//            }
//            logger.info("<|>login<|>update fansinfo >>" + fansInfo + "<|> success >> " + isSuccess);
//        }
//        Map<String,Object> resultMap = fansInfoService.initStartUpRegist(fansInfo);
//        fansInfo.setMedalCount(fansInfo.getMedalCount());
//        session.removeAttribute("fansInfo");session.setAttribute("fansInfo", fansInfo);
//        session.setMaxInactiveInterval(60*60*24);
//        
//        if(StringUtils.isNotBlank(redirectUrl)) {
//            if(redirectUrl.indexOf("_") > 0) {
//                redirectUrl = redirectUrl.replaceAll("_", "&");
//            }
//            return "redirect:" + redirectUrl;
//        }
//        
//        //歌手榜
//        String singerLabel = ServiceConst.SINGER_LABEL_HZPRELIMINARY;
//        List<BannerInfo> bannerInfoList = bannerService.queryBannerList();
//        System.out.println(openId+"----------------------查询首页内容" );
//        Page<SingerInfo> singerPage = singerService.querySingerPage(singerLabel,"" ,page, pageSize9, openId);
//        boolean loadAll=false;
//        if(singerPage.getResult()==null||singerPage.getResult().size()==0
//            ||singerPage.getTotalPages()== page){
//            loadAll = true;
//        }
//        //自动取号
//        if(unikey == null || unikey.isEmpty()){//如果unikey为空，则重定向首页
//            String uuidStr = UUID.randomUUID().toString().trim().replaceAll("-", "");
//            String suffix = "/wostar2/robTicket/toIndex.do?unikey="+uuidStr;
//            return "redirect:" + suffix;
//        }
//        String mobile = unicomUserService.getMsisdn(request, unikey);
//        session.setAttribute("getMobile", mobile);
//        
//        model.addAttribute("singerList", singerPage.getResult());
//        model.addAttribute("totalPage", singerPage.getTotalPages());
//        model.addAttribute("loadAll", loadAll);
//        model.addAttribute("singerLabel", singerLabel);
//        model.addAttribute("bannerInfoList", bannerInfoList);
//        model.addAttribute("fansInfo", fansInfo);
//        model.addAttribute("voteswitch", ServiceConst.VOTE_SWITCH);
//        logger.info("<|>logon success<|> openId >>" + openId);
//        return "activity/wostar2/index-1";
//    }
//    /**
//     * @Title: toIndex
//     * @Description: 首页
//     * @param code
//     * @param state OAuto授权后返回愿意参数（授权后重定向地址）,参数之间“_”分割
//     * @param session
//     * @return String 
//     */
//    @RequestMapping("toIndex2")
//    public String toIndex2(@RequestParam(required = false) String code, 
//    		@RequestParam(required = false) Integer page,
//    		@RequestParam(required = false) String redirectUrl,
//    		@RequestParam(required = false) String state,
//    		HttpSession session, Model model,HttpServletRequest request) {
//    	if(state!=null){
//    		redirectUrl=state;
//    	}
//    	if(null == page) {
//    		page = 1;
//    	}
//    	FansInfo fansInfo = (FansInfo)session.getAttribute("fansInfo");
////        String openId = "o0D8PuEk2Ock3jZ_UIbCEs8RMbW4";
////        String openId = "ogvWijhsGhY18tjCHs_MbFml6LqI";
////        String openId = "o0D8PuEk2Ock3jZ_UIbCEs8RMbW4";
////        fansInfo = new FansInfo();
////        fansInfo.setUopenid(openId);
////        fansInfo.setUnickname("流浪的睡睡");
////        fansInfo.setUsubscribe(1);
//    	String openId = null;
//    	if(StringUtils.isBlank(ObjectUtils.toString(fansInfo))) {
//    		String uuidStr = StringUtil.getUUidStr();
//    		String suffix = "/index/toIndex.do?unikey="+uuidStr;
//    		if(StringUtils.isNotBlank(redirectUrl)) {
//    			suffix = "/index/toIndex.do?unikey=" + uuidStr + 
//    					"&redirectUrl=" + redirectUrl;
//    		}
//    		logger.info("<|>wostar2<|>网页授权<|>code is>>>>>>>>" + code);
//    		if (StringUtils.isBlank(code)) {
//    			return "redirect:" + OAuth2Util.getCodeWithSuffix(suffix,redirectUrl);
//    		}
//    		openId = OAuth2Util.getOpenId(code);
//    		logger.info("<|>wostar2<|>网页授权<|>openId is>>>>>>>>" + openId);
//    		if (StringUtils.isBlank(openId)) {
//    			return "redirect:" + OAuth2Util.getCodeWithSuffix(suffix,redirectUrl);
//    		}
//    	}else {
//    		openId = fansInfo.getUopenid();
//    	}
//    	FansInfo wechatFansInfo = null;
//    	try {
//    		// 从微信接口获取粉丝信息
//    		String appId = propertyContext.get("appid");
//    		String appSecret = propertyContext.get("secret");
//    		wechatFansInfo = wechatInterfaceService.getFansInfo(openId, appId, appSecret);
//    	} catch (Exception e) {
//    		logger.info("<|>get fansInfo fail from weixin", e);
//    	}
//    	// 从数据库获取粉丝信息
//    	fansInfo = fansInfoService.findByOpenId(openId);
//    	if(fansInfo == null) { // 数据库找不到粉丝信息，则保存微信接口获取的粉丝信息
//    		if(wechatFansInfo != null) {
//    			fansInfo = wechatFansInfo;
//    		} else { 
//    			fansInfo = new FansInfo();
//    			fansInfo.setUopenid(openId);
//    			fansInfo.setUsubscribe(0);
//    		}
//    		try {
//    			fansInfo = fansInfoService.save(fansInfo);
//    		} catch (ApplicationException e) {
//    			logger.error("<|>login controller<|>save fansinfo fail<|>openId >>" + openId, e);
//    			fansInfo = fansInfoService.findByOpenId(openId);
//    		}
//    	} else if(wechatFansInfo != null) { // 更新粉丝信息
//    		fansInfo.setUsubscribe(wechatFansInfo.getUsubscribe());
//    		fansInfo.setUopenid(wechatFansInfo.getUopenid());
//    		fansInfo.setUnickname(wechatFansInfo.getUnickname());
//    		fansInfo.setUsex(wechatFansInfo.getUsex());
//    		fansInfo.setUlanguage(wechatFansInfo.getUlanguage());
//    		fansInfo.setUcity(wechatFansInfo.getUcity());
//    		fansInfo.setUprovince(wechatFansInfo.getUprovince());
//    		fansInfo.setUcountry(wechatFansInfo.getUcountry());
//    		fansInfo.setUheadimgurl(wechatFansInfo.getUheadimgurl());
//    		fansInfo.setUsubscribeTime(wechatFansInfo.getUsubscribeTime());
//    		
//    		boolean isSuccess = false;
//    		try {
//    			isSuccess = fansInfoService.update(fansInfo);
//    		} catch (ApplicationException e) {
//    			logger.error("<|>login controller<|>update fansinfo fail<|>openId >>" + openId, e);
//    		}
//    		logger.info("<|>login<|>update fansinfo >>" + fansInfo + "<|> success >> " + isSuccess);
//    	}
//    	
//    	Map<String,Object> resultMap = fansInfoService.initStartUpRegist(fansInfo);
//    	fansInfo.setMedalCount(fansInfo.getMedalCount());
//    	session.removeAttribute("fansInfo");session.setAttribute("fansInfo", fansInfo);
//    	session.setMaxInactiveInterval(60*60*24);
//    	
//    	if(StringUtils.isNotBlank(redirectUrl)) {
//    		redirectUrl = redirectUrl.replaceAll("_", "&");
//    		return "redirect:" + redirectUrl;
//    	}
//    	System.out.println(openId+"----------------------查询首页内容" );
//    	
//    	List<BannerInfo> bannerInfoList = bannerService.queryBannerList();
//    	
//    	//歌手榜
//    	
//    	String singerLabel = ServiceConst.SINGER_LABEL_CDEASTER +"JJC666JJC"+ServiceConst.SINGER_LABEL_ONLINEEASTER;
//    	String[] singerLabels = singerLabel.split("JJC666JJC");
//    	String singerLabel1 = singerLabels[0];
//    	String order = "FANS";
//    	Page<SingerInfo> pageSinger = singerService.querySingerPage(singerLabel1, order,page, pageSize40, openId);//晋级选手的榜单编码查询
//    	List<SingerInfo> singerList = pageSinger.getResult()==null?new ArrayList<SingerInfo>():pageSinger.getResult();
//    	int firstListCount = singerList.size();//用于普通榜单和晋级榜单的分离点,下拉和样式
//    	String singerLabel2 = null;
//    	List<SingerInfo> singerList2 = null;
//    	long totalPage = pageSinger.getTotalPages();
//    	if(singerLabels.length>1){
//    		singerLabel2 = singerLabels[1];
//    		order = "FANS";
//    		pageSinger  = singerService.querySingerPage(singerLabel2,order, page, pageSize40, openId);
//    		singerList2 = pageSinger.getResult();
//    		totalPage= pageSinger.getTotalPages();
//    	}else{//如果只有榜单,改字段
//    		firstListCount = 0;
//    	}
//    	boolean loadAll=false;
//    	if(pageSinger.getResult()==null||pageSinger.getResult().size()==0
//    			||pageSinger.getTotalPages()== page){
//    		loadAll = true;
//    	}
//    	model.addAttribute("bannerInfoList", bannerInfoList);
//    	model.addAttribute("fansInfo", fansInfo);
//    	model.addAttribute("voteswitch", ServiceConst.VOTE_SWITCH);
//    	
//    	model.addAttribute("singerList", singerList);
//    	model.addAttribute("singerList2", singerList2);
//    	model.addAttribute("totalPage", pageSinger.getTotalPages());
//    	model.addAttribute("loadAll", loadAll);
//    	model.addAttribute("firstListCount", firstListCount);
//    	model.addAttribute("singerLabel", singerLabel);
//    	model.addAttribute("totalPage", totalPage);
//    	model.addAttribute("order", order);
//    	logger.info("<|>logon success<|> openId >>" + openId);
////        return "activity/wostar2/index";//歌曲榜
//    	if(singerLabel.contains("JJC666JJC")){
//    		return "activity/wostar2/index-3";//晋级赛页面3
//    	}else{
//    		return "activity/wostar2/index-1"; //初赛赛页面
//    	}
//    }
////    /**
////     * @Title: toIndex
////     * @Description: 首页
////     * @param code
////     * @param state OAuto授权后返回愿意参数（授权后重定向地址）,参数之间“_”分割
////     * @param session
////     * @return String 
////     */
////    @RequestMapping("toIndex")
////    public String toIndex(@RequestParam(required = false) String code, 
////    		@RequestParam(required = false) Integer page,
////    		@RequestParam(required = false) String redirectUrl,
////    		@RequestParam(required = false) String state,
////    		@RequestParam(required = false) String unikey,
////    		HttpSession session, Model model,HttpServletRequest request) {
////    	if(state!=null){
////    		redirectUrl=state;
////    	}
////    	if(null == page) {
////    		page = 1;
////    	}
////    	FansInfo fansInfo = (FansInfo)session.getAttribute("fansInfo");
//////        String openId = "o0D8PuEk2Ock3jZ_UIbCEs8RMbW4";
//////        String openId = "ogvWijhsGhY18tjCHs_MbFml6LqI";
//////        String openId = "o0D8PuEk2Ock3jZ_UIbCEs8RMbW4";
//////        fansInfo = new FansInfo();
//////        fansInfo.setUopenid(openId);
//////        fansInfo.setUnickname("流浪的睡睡");
//////        fansInfo.setUsubscribe(1);
////    	String openId = null;
////    	if(StringUtils.isBlank(ObjectUtils.toString(fansInfo))) {
////    		String uuidStr = StringUtil.getUUidStr();
////    		String suffix = "/index/toIndex.do?unikey="+uuidStr;
////    		if(StringUtils.isNotBlank(redirectUrl)) {
////    			suffix = "/index/toIndex.do?unikey=" + uuidStr + 
////    					"&redirectUrl=" + redirectUrl;
////    		}
////    		logger.info("<|>wostar2<|>网页授权<|>code is>>>>>>>>" + code);
////    		if (StringUtils.isBlank(code)) {
////    			return "redirect:" + OAuth2Util.getCodeWithSuffix(suffix,redirectUrl);
////    		}
////    		openId = OAuth2Util.getOpenId(code);
////    		logger.info("<|>wostar2<|>网页授权<|>openId is>>>>>>>>" + openId);
////    		if (StringUtils.isBlank(openId)) {
////    			return "redirect:" + OAuth2Util.getCodeWithSuffix(suffix,redirectUrl);
////    		}
////    	}else {
////    		openId = fansInfo.getUopenid();
////    	}
////    	FansInfo wechatFansInfo = null;
////    	try {
////    		// 从微信接口获取粉丝信息
////    		String appId = propertyContext.get("appid");
////    		String appSecret = propertyContext.get("secret");
////    		wechatFansInfo = wechatInterfaceService.getFansInfo(openId, appId, appSecret);
////    	} catch (Exception e) {
////    		logger.info("<|>get fansInfo fail from weixin", e);
////    	}
////    	// 从数据库获取粉丝信息
////    	fansInfo = fansInfoService.findByOpenId(openId);
////    	if(fansInfo == null) { // 数据库找不到粉丝信息，则保存微信接口获取的粉丝信息
////    		if(wechatFansInfo != null) {
////    			fansInfo = wechatFansInfo;
////    		} else { 
////    			fansInfo = new FansInfo();
////    			fansInfo.setUopenid(openId);
////    			fansInfo.setUsubscribe(0);
////    		}
////    		try {
////    			fansInfo = fansInfoService.save(fansInfo);
////    		} catch (ApplicationException e) {
////    			logger.error("<|>login controller<|>save fansinfo fail<|>openId >>" + openId, e);
////    			fansInfo = fansInfoService.findByOpenId(openId);
////    		}
////    	} else if(wechatFansInfo != null) { // 更新粉丝信息
////			fansInfo.setUsubscribe(wechatFansInfo.getUsubscribe());
////			fansInfo.setUopenid(wechatFansInfo.getUopenid());
////			fansInfo.setUnickname(ParamUtil.rplStr(wechatFansInfo.getUnickname(),fansInfo.getUnickname()));
////			fansInfo.setUsex(wechatFansInfo.getUsex());
////			fansInfo.setUlanguage(ParamUtil.rplStr(wechatFansInfo.getUlanguage(),fansInfo.getUlanguage()));
////			fansInfo.setUcity(ParamUtil.rplStr(wechatFansInfo.getUcity(),fansInfo.getUcity()));
////			fansInfo.setUprovince(ParamUtil.rplStr(wechatFansInfo.getUprovince(),fansInfo.getUprovince()));
////			fansInfo.setUcountry(ParamUtil.rplStr(wechatFansInfo.getUcountry(),fansInfo.getUcountry()));
////			fansInfo.setUheadimgurl(ParamUtil.rplStr(wechatFansInfo.getUheadimgurl(),fansInfo.getUheadimgurl()));
////			fansInfo.setUsubscribeTime(wechatFansInfo.getUsubscribeTime());
////    		
////    		boolean isSuccess = false;
////    		try {
////    			isSuccess = fansInfoService.update(fansInfo);
////    		} catch (ApplicationException e) {
////    			logger.error("<|>login controller<|>update fansinfo fail<|>openId >>" + openId, e);
////    		}
////    		logger.info("<|>login<|>update fansinfo >>" + fansInfo + "<|> success >> " + isSuccess);
////    	}
////    	
////    	Map<String,Object> resultMap = fansInfoService.initStartUpRegist(fansInfo);
////    	fansInfo.setMedalCount(fansInfo.getMedalCount());
////    	session.removeAttribute("fansInfo");session.setAttribute("fansInfo", fansInfo);
////    	session.setMaxInactiveInterval(60*60*24);
////    	
////    	if(StringUtils.isNotBlank(redirectUrl)) {
////    		redirectUrl = redirectUrl.replaceAll("_", "&");
////    		return "redirect:" + redirectUrl;
////    	}
////    	System.out.println(openId+"----------------------查询首页内容" );
////    	
////    	List<BannerInfo> bannerInfoList = bannerService.queryBannerList();
////    	
////    	//歌手榜
////    	
////    	String order = "FANS";
////    	String singerLabel1 = ServiceConst.SINGER_LABEL_TOP30;
////    	String singerLabel2 = ServiceConst.SINGER_LABEL_GZFINALS;
////    	String singerLabel3 = ServiceConst.SINGER_LABEL_TOP20;
////    	Page<SingerInfo> pageSinger2 = singerService.querySingerPage(singerLabel2, order,page, pageSize40, openId);
////    	Page<SingerInfo> pageSinger1 = pageSinger2;
////    	
////    	Page<SingerInfo> pageSinger3 = singerService.querySingerPage(singerLabel3, order,page, pageSize10, openId);
////    	
////    	List<SingerInfo> singerList1 = pageSinger1.getResult()==null?new ArrayList<SingerInfo>():pageSinger1.getResult();
////    	SingerInfo singerInfo1 = null;
////    	if(singerList1!=null&&singerList1.size()>0){
////    		singerInfo1 = singerList1.get(0);
////    	}
////    	int firstListCount = 1;//singerList1是30强人气王，值取第一个
////    	
////    	List<SingerInfo> singerList2 = pageSinger2.getResult()==null?new ArrayList<SingerInfo>():pageSinger2.getResult();
////    	int secondListCount = singerList2.size();
////    	
////    	List<SingerInfo> singerList3 = pageSinger3.getResult()==null?new ArrayList<SingerInfo>():pageSinger3.getResult();
////    	
////        String uuidStr = UUID.randomUUID().toString().trim().replaceAll("-", "");
////    	
////    	model.addAttribute("unikey", uuidStr);
////    	model.addAttribute("bannerInfoList", bannerInfoList);
////    	model.addAttribute("fansInfo", fansInfo);
////    	
////    	model.addAttribute("singerInfo1", singerInfo1);
////    	model.addAttribute("singerList2", singerList2);
////    	model.addAttribute("singerList3", singerList3);
////    	model.addAttribute("loadAll", true);
////    	model.addAttribute("firstListCount", firstListCount);
////    	model.addAttribute("secondListCount", secondListCount);
////    	model.addAttribute("order", order);
////    	model.addAttribute("totalPage", pageSinger3.getTotalPages());
////    	model.addAttribute("pageSize", pageSize10);
////    	logger.info("<|>logon success<|> openId >>" + openId);
////    	
////    	return "activity/wostar2/index-5";
////    }
//    
//    /**
//     * @Title: loadMoreRole
//     * @Description: 加载更多全够20强
//     * @param page
//     * @param session
//     * @return String 
//     */
//    @RequestMapping("loadMore")
//    public @ResponseBody String loadMore(@RequestParam int page,
//             HttpSession session) {
//        JSONObject jsonObj = new JSONObject();
//        FansInfo fansInfo = (FansInfo)session.getAttribute("fansInfo");
//        String openId = fansInfo.getUopenid();
//        String singerLabel3 = ServiceConst.SINGER_LABEL_TOP20;
//        String order = "FANS";
//        Page<SingerInfo> pageSinger3 = singerService.querySingerPage(
//                singerLabel3, order,page, pageSize10, openId);
//        
//        jsonObj.put("singerList3", pageSinger3.getResult());
//        return jsonObj.toString();
//    }
//    @RequestMapping("checkOS")
//    public String checkOS(HttpServletRequest request,HttpServletResponse responseh,HttpSession session){
//    	Enumeration<String> e = request.getHeaderNames();
//    	System.out.println("-------------------头信息开始---");
//    	while(e.hasMoreElements()){
//    		String name = e.nextElement();
//    		System.out.println(name+":= " + request.getHeader(name));
//    	}
//    	System.out.println("-------------头信息结束--");
//    	String ip1 = HttpUtil.getIpAddr(request);
//    	String ip2 = HttpUtil.getIpAddr2(request);
//    	System.out.println("获取到的IP1:"+ip1);
//    	System.out.println("获取到的IP2:"+ip2);
//    	String unikey = request.getParameter("unikey");
//    	String m1 = unicomUserService.getMsisdn(request, unikey);
//    	String m2 = unicomUserService.getMsisdn2(request, unikey);
//    	System.out.println("获取到的手机号1:"+m1);
//    	System.out.println("获取到的手机号2:"+m2);
//    	return "activity/wostar2/checkOS";
//    }
//    
//    /**
//     * @Title: toIndex
//     * @Description: 首页
//     * @param code
//     * @param state OAuto授权后返回愿意参数（授权后重定向地址）,参数之间“_”分割
//     * @param session
//     * @return String 
//     */
//    @RequestMapping("toIndex")
//    public String toIndex(@RequestParam(required = false) String code, 
//            @RequestParam(required = false) Integer page,
//            @RequestParam(required = false) String redirectUrl,
//            @RequestParam(required = false) String state,
//            @RequestParam(required = false) String unikey,
//            HttpSession session, Model model,HttpServletRequest request) {
//        if(state!=null){
//            redirectUrl=state;
//        }
//        if(null == page) {
//            page = 1;
//        }
//        FansInfo fansInfo = (FansInfo)session.getAttribute("fansInfo");
////        String openId = "o0D8PuEk2Ock3jZ_UIbCEs8RMbW4";
////        String openId = "ogvWijhsGhY18tjCHs_MbFml6LqI";
////        String openId = "o0D8PuEk2Ock3jZ_UIbCEs8RMbW4";
////        fansInfo = new FansInfo();
////        fansInfo.setUopenid(openId);
////        fansInfo.setUnickname("流浪的睡睡");
////        fansInfo.setUsubscribe(1);
//      String openId = null;
//      if(StringUtils.isBlank(ObjectUtils.toString(fansInfo))) {
//          String uuidStr = StringUtil.getUUidStr();
//          String suffix = "/index/toIndex.do?unikey="+uuidStr;
//          if(StringUtils.isNotBlank(redirectUrl)) {
//              suffix = "/index/toIndex.do?unikey=" + uuidStr + 
//                      "&redirectUrl=" + redirectUrl;
//          }
//          logger.info("<|>wostar2<|>网页授权<|>code is>>>>>>>>" + code);
//          if (StringUtils.isBlank(code)) {
//              return "redirect:" + OAuth2Util.getCodeWithSuffix(suffix,redirectUrl);
//          }
//          openId = OAuth2Util.getOpenId(code);
//          logger.info("<|>wostar2<|>网页授权<|>openId is>>>>>>>>" + openId);
//          if (StringUtils.isBlank(openId)) {
//              return "redirect:" + OAuth2Util.getCodeWithSuffix(suffix,redirectUrl);
//          }
//      }else {
//          openId = fansInfo.getUopenid();
//      }
//      FansInfo wechatFansInfo = null;
//      try {
//          // 从微信接口获取粉丝信息
//          String appId = propertyContext.get("appid");
//          String appSecret = propertyContext.get("secret");
//          wechatFansInfo = wechatInterfaceService.getFansInfo(openId, appId, appSecret);
//      } catch (Exception e) {
//          logger.info("<|>get fansInfo fail from weixin", e);
//      }
//      // 从数据库获取粉丝信息
//      fansInfo = fansInfoService.findByOpenId(openId);
//      if(fansInfo == null) { // 数据库找不到粉丝信息，则保存微信接口获取的粉丝信息
//          if(wechatFansInfo != null) {
//              fansInfo = wechatFansInfo;
//          } else { 
//              fansInfo = new FansInfo();
//              fansInfo.setUopenid(openId);
//              fansInfo.setUsubscribe(0);
//          }
//          try {
//              fansInfo = fansInfoService.save(fansInfo);
//          } catch (ApplicationException e) {
//              logger.error("<|>login controller<|>save fansinfo fail<|>openId >>" + openId, e);
//              fansInfo = fansInfoService.findByOpenId(openId);
//          }
//      } else if(wechatFansInfo != null) { // 更新粉丝信息
//          fansInfo.setUsubscribe(wechatFansInfo.getUsubscribe());
//          fansInfo.setUopenid(wechatFansInfo.getUopenid());
//          fansInfo.setUnickname(ParamUtil.rplStr(wechatFansInfo.getUnickname(),fansInfo.getUnickname()));
//          fansInfo.setUsex(wechatFansInfo.getUsex());
//          fansInfo.setUlanguage(ParamUtil.rplStr(wechatFansInfo.getUlanguage(),fansInfo.getUlanguage()));
//          fansInfo.setUcity(ParamUtil.rplStr(wechatFansInfo.getUcity(),fansInfo.getUcity()));
//          fansInfo.setUprovince(ParamUtil.rplStr(wechatFansInfo.getUprovince(),fansInfo.getUprovince()));
//          fansInfo.setUcountry(ParamUtil.rplStr(wechatFansInfo.getUcountry(),fansInfo.getUcountry()));
//          fansInfo.setUheadimgurl(ParamUtil.rplStr(wechatFansInfo.getUheadimgurl(),fansInfo.getUheadimgurl()));
//          fansInfo.setUsubscribeTime(wechatFansInfo.getUsubscribeTime());
//          
//          boolean isSuccess = false;
//          try {
//              isSuccess = fansInfoService.update(fansInfo);
//          } catch (ApplicationException e) {
//              logger.error("<|>login controller<|>update fansinfo fail<|>openId >>" + openId, e);
//          }
//          logger.info("<|>login<|>update fansinfo >>" + fansInfo + "<|> success >> " + isSuccess);
//      }
//        
//        Map<String,Object> resultMap = fansInfoService.initStartUpRegist(fansInfo);
//        fansInfo.setMedalCount(fansInfo.getMedalCount());
//        session.removeAttribute("fansInfo");session.setAttribute("fansInfo", fansInfo);
//        session.setMaxInactiveInterval(60*60*24);
//        
//        if(StringUtils.isNotBlank(redirectUrl)) {
//            redirectUrl = redirectUrl.replaceAll("_", "&");
//            return "redirect:" + redirectUrl;
//        }
//        System.out.println(openId+"----------------------查询首页内容" );
//        
//        List<BannerInfo> bannerInfoList = bannerService.queryBannerList();
//        
//        String uuidStr = UUID.randomUUID().toString().trim().replaceAll("-", "");
//        
//        String userMobile = mobileUtil.getMobile(fansInfo, unikey, session, request);
//        
//        //冠亚季军榜单
//        String orderByBoard = "BOARD";
//        String labelOfTop = ServiceConst.SINGER_LABEL_FINALCHAMPION;
//        Page<SingerInfo> singerPageOfTop = singerService.querySingerPage(labelOfTop, 
//                orderByBoard, 1, 3, openId);
//        //人气王榜单
//        String orderByFans = "BOARD";
//        String labelBySingerpopularity = ServiceConst.SINGER_LABEL_SINGERPOPULARITY;
//        Page<SingerInfo> singerPageOfPop = singerService.querySingerPage(labelBySingerpopularity, 
//                orderByFans, 1, 2, openId);
//        
//        //铃音盒
//        String musicBoxLabel = ServiceConst.MUSICBOX_BOX_CODE;
//        MusicboxInfo musicboxInfo = musicboxService.queryInfo(openId, musicBoxLabel);
//        
//        //参赛选手
//        String labelOfActivity = ServiceConst.SINGER_LABEL_ACTIVITYSONG;
//        String orderByActivity = "FANS";
//        Page<SongInfo> songPage = songService.querySongPage2(labelOfActivity, 1, 
//                pageSize4, openId, orderByActivity);
//        
//        model.addAttribute("unikey", uuidStr);
//        model.addAttribute("bannerInfoList", bannerInfoList);
//        model.addAttribute("fansInfo", fansInfo);
//        
//        model.addAttribute("userMobile", userMobile);
//        model.addAttribute("songList", songPage.getResult());
//        model.addAttribute("musicboxInfo", musicboxInfo);
//        model.addAttribute("singerOfTop3", singerPageOfTop.getResult().size() != 0 ? singerPageOfTop.getResult() : null);
//        model.addAttribute("singerOfPopList", singerPageOfPop.getResult());
//        
//        model.addAttribute("loadAll", true);
//        model.addAttribute("totalPage", songPage.getTotalPages());
//        model.addAttribute("pageSize", pageSize4);
//        logger.info("<|>logon success<|> openId >>" + openId);
//        
//        return "activity/wostar2/theEnd";
//    }
}
