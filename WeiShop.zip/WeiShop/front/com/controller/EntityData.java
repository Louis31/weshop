package com.controller;

import java.util.List;

public class EntityData<T> {  
    
    private List<T> records;  
  
    public List<T> getRecords() {  
        return records;  
    }  
  
    public void setRecords(List<T> records) {  
        this.records = records;  
    }  
  
      
}  