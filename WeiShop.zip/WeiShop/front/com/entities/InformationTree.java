package com.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "informationTree")
public class InformationTree {
	
	private long id;
	private String infoname;
	private long pid;
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
	@Column(name ="id",nullable=false)
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	@Column(name ="infoname",nullable=false)
	public String getInfoname() {
		return infoname;
	}
	public void setInfoname(String infoname) {
		this.infoname = infoname;
	}
	
	@Column(name ="pid",nullable=false)
	public long getPid() {
		return pid;
	}
	public void setPid(long pid) {
		this.pid = pid;
	}

	
	
}
