package com.entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * TbuserInfo entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "tbuser")
public class Tbuser  implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Fields

	private Integer userId;
	private String userName;
	public Tbuser() {
	}

	/** minimal constructor */
	public Tbuser(Integer userId) {
		this.userId = userId;
	}
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
	@Column(name ="id",nullable=false)	
	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	@Column(name = "user_name", length = 64)
	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}