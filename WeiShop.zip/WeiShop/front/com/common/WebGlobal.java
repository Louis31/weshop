package com.common;

import javax.servlet.http.HttpServletRequest;

/**
 * 全局配置类
 *
 */
public class WebGlobal {
	
	// ///////////////////////////////////////////////////////
	
	/**
	 * 获取系统当前根路径
	 * 
	 * @param request
	 * @return
	 */
	public static String getBasePath(HttpServletRequest request) {		
		String path = request.getContextPath();
		return request.getScheme() + "://" + request.getServerName() + ":"
				+ request.getServerPort() + path + "/";
	}
	public static String getLogTabel(){
		return SysContext.getConfig("db.logTabel");
	}
	/**
	 * 获取组织机构根节点ID
	 * @return
	 */
	public static String getLibPath() {
		return SysContext.getConfig("Sys.LibPath");
	}
	/**
	 * 获取组织机构根节点ID
	 * @return
	 */
	public static String getOrgRootID() {
		return SysContext.getConfig("Sys.OrgRootID");
	}
	
	/**
	 * 获取系统视图路径  相对于spring mvc 视图解析器 扫描的路径
	 * @return
	 */
	public static String getSystemViewPath() {
		return "modules/system";
	}
	
	public static String getLonkoomViewPath() {
		return "modules/lonkoom";
	}
	
	public static String getAdminViewPath() {
		return "modules/weshop";
	}
	
	/**
	 * 获取业务模块的视图根路径
	 * @return
	 */
	public static String getModulesPath() {
		return "modules";
	}

	/**
	 * 获取前端根路径
	 */
	public static String getFrontPath() {
		return SysContext.getConfig("frontPath");
	}

	/**
	 * 获取URL后缀
	 */
	public static String getUrlSuffix() {
		return SysContext.getConfig("urlSuffix");
	}

	/**
	 * 是否是演示模式，演示模式下不能修改用户、角色、密码、菜单、授权
	 */
	public static Boolean isDemoMode() {
		String dm = SysContext.getConfig("demoMode");
		return "true".equals(dm) || "1".equals(dm);
	}
}
