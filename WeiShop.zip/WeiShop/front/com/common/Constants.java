package com.common;

/**
 * 系统常量
 * @author ZYZ
 *
 */
public class Constants {
    public static final String CURRENT_USER = "user";
    public static final String VALIDATE_CODE = "validateCode";
    public static final String UPLOAD_FILE_DIR="upload";
}
