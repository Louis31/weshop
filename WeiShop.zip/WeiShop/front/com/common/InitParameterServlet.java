package com.common;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InitParameterServlet
 */
@WebServlet("/InitParameterServlet")
public class InitParameterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InitParameterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    /**
     * 将web.xml 中设置的参数放到application 对象中
     */
    public void init(ServletConfig config)
            throws ServletException
        {
    		super.init( config );
    		String basepathString=getInitParameter("BasePath");
    		String orgrootid=getInitParameter("OrgRootID");
    		config.getServletContext().setAttribute("BasePath", basepathString);
    		config.getServletContext().setAttribute("OrgRootID", orgrootid);
        }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
