package com.base;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;

import com.common.PageInfo;
public interface IBaseDao<T> {
	
	public Session getSession();
	/**
	 * 强制与数据库同步
	 */
	public void flush();
	/**
	 * 清楚缓存数据
	 */
	public void clear();
	
	//----------------------entity operation--------------------
	//保存	
	/**
	 * 保存
	 * @param entity
	 * @return
	 */
	public Serializable save(T entity);
	/**
	 * 批量保存
	 * @param entitys
	 */
	public void batchSave(List<T> entitys);
	/**
	 * 更新
	 * @param entity
	 */
	public void update(T entity);
	/**
	 * 跟新一批
	 * @param entitys
	 */
	public void batchUpdate(List<T> entitys);
	//删除	
	/**
	 * 删除实体
	 * @param entitie
	 */
	public void delete(T entity);
	/**
	 * 删除指定实体
	 * @param id
	 */
	public void deleteEntityById(Serializable id);
	/**
	 * 批量删除实体
	 * @param entities
	 */
	public void batchDeleteEntities(List<T> entities);
	/**
	 * 批量删除指定ID实体
	 * @param ids
	 */
	public void batchDeleteEntitiesByID(List<Serializable> ids);
	
	//获取	
	/**
	 * 通过属性查找唯一实体,多个时产生异常
	 * @param propertyName
	 * @param value
	 * @return
	 */
	public T singleByProperty(String propertyName, Object value);
	/**
	 * 通过属性查找一批实体
	 * @param propertyName
	 * @param value
	 * @return
	 */
	public List<T> findByProperty(String propertyName, Object value);
	/**
	 * 获取所有实体
	 * @return
	 */
	public List<T> findAll();
	/**
	 * 获取指定ID实体
	 * @param id
	 * @return
	 */
	public T getEntity(Serializable id);
	
	//----------------------------HQL Query----------------------------
	/**
	 * 返回 hql 查询结果集
	 * @param hql
	 * @return
	 */
	public List<T> findByHQL(String hql);
	/**
	 * 返回 hql 查询的单个对象，多个时抛出异常
	 * @param hql
	 * @return
	 */
	public T singleByHQL(String hql);
	
	/**
	 * 返回 符合hql查询结果的指定页结果 
	 * @param hql
	 * @param pageInfo 分页信息对象，为了防止对同一条件重复统计记录总数，请保持该对象的状态。
	 * 如果条件有变化，要重新统计总记录数，必须重新设置allSize为-1
	 * @return
	 */
	public List<T> findPageByHQL(String hql,PageInfo pageInfo);
	/**
	 * 统计符合hql记录数
	 * @param hql
	 * @return
	 */
	public long countByHQL(String hql);
	
	/**
	 * 更新 By HQL
	 * @param hql
	 * @return
	 */
	public int updateByHQL(String hql);
	
	/**
	 * 执行HQL语句，返回受影响的行数
	 * @param hql
	 * @return
	 */
	public int executeHQL(String hql);
	
	// -------------------------- SQL Query -----------------
	/**
	 * 返回 sql 查询结果集
	 * @param sql
	 * @return
	 */
	public List<T> findBySQL(String sql);
	
	
	/**
	 * 返回 符合sql查询结果的指定页结果
	 * @param sql
	 * @param pageInfo 分页信息对象，为了防止对同一条件重复统计记录总数，请保持该对象的状态。
	 * 如果条件有变化，要重新统计总记录数，必须重新设置allSize为-1
	 * @return
	 */
	public List<T> findPageBySQL(String sql,PageInfo pageInfo);
	
	/**
	 * 统计符合sql记录数
	 * @param sql
	 * @return
	 */
	public long countBySQL(String sql);
	/**
	 * 执行SQL更新语句
	 * @param sqlString
	 * @return
	 */
	public int updateBySql(String sqlString);
	// ----------------------- Criteria Query----------------------------
	
	/**
	 * 返回 criteria 查询结果集
	 * @param sql
	 * @return
	 */
	public List<T> findByCriteria(DetachedCriteria criteria);
	/**
	 * 返回 criteria 查询的单个对象，多个时抛出异常
	 * @param criteria
	 * @return
	 */
	public T singleByCriteria(DetachedCriteria criteria);
	
	/**
	 * 返回 符合 criteria 查询结果的指定页结果
	 * @param criteria
	 * @param pageInfo 分页信息对象，为了防止对同一条件重复统计记录总数，请保持该对象的状态。
	 * 如果条件有变化，要重新统计总记录数，必须重新设置allSize为-1
	 * @param orderBy abc desc,ded asc (多个排序半角逗号分开)
	 * @return
	 */
	public List<T> findPageByCriteria(DetachedCriteria criteria,PageInfo pageInfo,String orderBy);
	
	/**
	 * 统计符合criteria记录数
	 * @param criteria
	 * @return
	 */
	public long countByCriteria(DetachedCriteria criteria);
}
