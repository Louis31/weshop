package com.base;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.internal.CriteriaImpl;
import org.springframework.util.Assert;

import com.common.PageInfo;
import com.common.StringUtils;


@SuppressWarnings("all")
public class BaseDaoImpl<T> implements IBaseDao<T> {

	/**
	 * 初始化Log4j的一个实例
	 */
	private static final Logger logger = Logger.getLogger(BaseDaoImpl.class);
	
	/**
	 * 实体类类型(由构造方法自动赋值)
	 */
	private Class<T> entityClass;
	
	/**
	 * 构造方法，根据实例类自动获取实体类类型
	 */
	public BaseDaoImpl() {
		entityClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];		
	}

	/**
	 * 注入一个sessionFactory属性,并注入到父类(HibernateDaoSupport)
	 * **/
	@Resource
	private SessionFactory sessionFactory;

	@Override
	public Session getSession() {
		// 事务必须是开启的(Required)，否则获取不到
		return sessionFactory.getCurrentSession();
	}
	
	@Override
	public void flush() {		
		getSession().flush();
	}

	@Override
	public void clear() {		
		getSession().clear();
	}

	@Override
	public Serializable save(T entity) {
		try {
			Session session = getSession();
			Serializable id = session.save(entity);
			session.flush();
			if (logger.isDebugEnabled()) {
				logger.debug("保存实体成功," + entity.getClass().getName());
			}
			return id;
		} catch (RuntimeException e) {
			logger.error("保存实体异常", e);
			throw e;
		}
	}

	@Override
	public void batchSave(List<T> entitys) {
		for (int i = 0; i < entitys.size(); i++) {
			getSession().save(entitys.get(i));
			if (i % 20 == 0) {
				// 20个对象后才清理缓存，写入数据库
				getSession().flush();
				getSession().clear();
			}
		}
		// 最后清理一下----防止大于20小于40的不保存
		getSession().flush();
		getSession().clear();
	}

	@Override
	public void update(T entity) {
		try {
			getSession().saveOrUpdate(entity);
			getSession().flush();
			if (logger.isDebugEnabled()) {
				logger.debug("添加或更新成功," + entity.getClass().getName());
			}
		} catch (RuntimeException e) {
			logger.error("添加或更新异常", e);
			throw e;
		}
	}

	@Override
	public void batchUpdate(List<T> entitys) {
		for (int i = 0; i < entitys.size(); i++) {
			getSession().saveOrUpdate(entitys.get(i));
			if (i % 20 == 0) {
				// 20个对象后才清理缓存，写入数据库
				getSession().flush();
				getSession().clear();
			}
		}
		// 最后清理一下----防止大于20小于40的不保存
		getSession().flush();
		getSession().clear();
	}

	@Override
	public void delete(T entity) {
		try {
			getSession().delete(entity);
			getSession().flush();
			if (logger.isDebugEnabled()) {
				logger.debug("删除成功," + entity.getClass().getName());
			}
		} catch (RuntimeException e) {
			logger.error("删除异常", e);
			throw e;
		}
	}

	@Override
	public void deleteEntityById(Serializable id) {
		delete(getEntity(id));
		// getSession().flush();
	}

	@Override
	public void batchDeleteEntities(List<T> entities) {
		for (int i = 0; i < entities.size(); i++) {
			getSession().delete(entities.get(i));
			if (i % 20 == 0) {
				// 20个对象后才清理缓存，写入数据库
				getSession().flush();
			}
		}
		// 最后清理一下----防止大于20小于40的不保存
		getSession().flush();
	}

	@Override
	public void batchDeleteEntitiesByID(List<Serializable> ids) {
		for (int i = 0; i < ids.size(); i++) {
			getSession().delete(getEntity(ids.get(i)));
			if (i % 20 == 0) {
				// 20个对象后才清理缓存，写入数据库
				getSession().flush();
			}
		}
		// 最后清理一下----防止大于20小于40的不保存
		getSession().flush();
	}

	@Override
	public T singleByProperty(String propertyName, Object value) {
		Assert.hasText(propertyName);		
		return (T) createCriteria(entityClass, Restrictions.eq(propertyName, value))
				.uniqueResult();
	}

	@Override
	public List<T> findByProperty(String propertyName, Object value) {
		Assert.hasText(propertyName);		
		return (List<T>) createCriteria(entityClass,
				Restrictions.eq(propertyName, value)).list();
	}

	@Override
	public List<T> findAll() {		
		Criteria criteria = createCriteria(entityClass);
		return criteria.list();
	}

	@Override
	public T getEntity(Serializable id) {		
		return (T) getSession().get(entityClass, id);
	}

	
	//----------------------------HQL Query----------------------------

	@Override
	public List<T> findByHQL(String hql) {
		return createQuery(hql).list();
	}

	@Override
	public T singleByHQL(String hql) {
		return (T)createQuery(hql).uniqueResult();
	}

	@Override
	public List<T> findPageByHQL(String hql, PageInfo pageInfo) {
		
		// get count
		if(pageInfo.isNotCount()){
		pageInfo.setAllSize(countByHQL(hql));
		if(pageInfo.getAllSize()==0)return new ArrayList<T>();;
		}
    	
		//get data
		Query pagequery = createQuery(hql); 
    	// set page
		pagequery.setFirstResult(pageInfo.getFirstResult());
		pagequery.setMaxResults(pageInfo.getMaxResults()); 
       
		return pagequery.list();
	}

	@Override
	public long countByHQL(String hql) {		
		String countQlString = "select count(*) " + removeSelect(removeOrders(hql)); 
		Query query = createQuery(countQlString);
		List<Object> list = query.list();		
        if (list.size() > 0){
        	return Long.valueOf(list.get(0).toString());
        }else{
        	return 0;
        }		
	}
	
	// -------------------------- SQL Query -----------------

	@Override
	public List<T> findBySQL(String sql) {
		SQLQuery query = createSqlQuery(sql);	
		query.addEntity(entityClass);
		return query.list();
	}

	@Override
	public List<T> findPageBySQL(String sql, PageInfo pageInfo) {
		
		// get count	
		if(pageInfo.isNotCount()){
		pageInfo.setAllSize(countBySQL(sql));
		if(pageInfo.getAllSize()==0)return new ArrayList<T>();
		}
        SQLQuery query = createSqlQuery(sql); 
        query.addEntity(entityClass);
		// set page
        query.setFirstResult(pageInfo.getFirstResult());
        query.setMaxResults(pageInfo.getMaxResults()); 
       
        return query.list();
	}

	@Override
	public long countBySQL(String sql) {
		String countSqlString = "select count(*) " + removeSelect(removeOrders(sql));  
//        page.setCount(Long.valueOf(createSqlQuery(countSqlString, parameter).uniqueResult().toString()));
        Query query = createSqlQuery(countSqlString);
        List<Object> list = query.list();
        if (list.size() > 0){
        	return Long.valueOf(list.get(0).toString());
        }else{
        	return 0;
        }		
	}

	// ----------------------- Criteria Query----------------------------
	@Override
	public List<T> findByCriteria(DetachedCriteria criteria) {
		Criteria querycriteria = criteria.getExecutableCriteria(getSession());		
		return querycriteria.list(); 
	}

	@Override
	public T singleByCriteria(DetachedCriteria criteria) {
		Criteria querycriteria = criteria.getExecutableCriteria(getSession());		
		return (T)querycriteria.uniqueResult();
	}

	@Override
	public List<T> findPageByCriteria(DetachedCriteria criteria,
			PageInfo pageInfo,String orderBy) {
						// get count	
			if(pageInfo.isNotCount()){
			pageInfo.setAllSize(countByCriteria(criteria));
			if(pageInfo.getAllSize()==0)return new ArrayList<T>();
			}
				Criteria querycriteria = criteria.getExecutableCriteria(getSession());
		
				// set page
				querycriteria.setFirstResult(pageInfo.getFirstResult());
				querycriteria.setMaxResults(pageInfo.getMaxResults()); 
		        
				// order by
				if (StringUtils.isNotBlank(orderBy)){
					for (String order : StringUtils.split(orderBy, ",")){
						String[] o = StringUtils.split(order, " ");
						if (o.length==1){
							criteria.addOrder(Order.asc(o[0]));
						}else if (o.length==2){
							if ("DESC".equals(o[1].toUpperCase())){
								criteria.addOrder(Order.desc(o[0]));
							}else{
								criteria.addOrder(Order.asc(o[0]));
							}
						}
					}
				}				
				
				return querycriteria.list();
				
	}

	@Override
	public long countByCriteria(DetachedCriteria criteria) {
		Criteria queryCriteria = criteria.getExecutableCriteria(getSession());
		long totalCount = 0;
		try {
			// Get orders
			Field field = CriteriaImpl.class.getDeclaredField("orderEntries");
			field.setAccessible(true);
			List orderEntrys = (List)field.get(queryCriteria);
			// Remove orders
			field.set(queryCriteria, new ArrayList());
			// Get count
			queryCriteria.setProjection(Projections.rowCount());
			totalCount = Long.valueOf(queryCriteria.uniqueResult().toString());
			// Clean count
			queryCriteria.setProjection(null);
			// Restore orders
			field.set(queryCriteria, orderEntrys);
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return totalCount;
	}

	// -------------- Query Tools --------------
	/** 
     * 去除qlString的select子句。 
     * @param qlString
     * @return 
     */  
    private String removeSelect(String qlString){  
        int beginPos = qlString.toLowerCase().indexOf("from");  
        return qlString.substring(beginPos);  
    }  
      
    /** 
     * 去除hql的orderBy子句。 
     * @param qlString
     * @return 
     */  
    private String removeOrders(String qlString) {  
        Pattern p = Pattern.compile("order\\s*by[\\w|\\W|\\s|\\S]*", Pattern.CASE_INSENSITIVE);  
        Matcher m = p.matcher(qlString);  
        StringBuffer sb = new StringBuffer();  
        while (m.find()) {  
            m.appendReplacement(sb, "");  
        }
        m.appendTail(sb);
        return sb.toString();  
    } 
    
    /**
	 * 创建 QL 查询对象
	 * @param qlString
	 * @param parameter
	 * @return
	 */
	private Query createQuery(String qlString){
		Query query = getSession().createQuery(qlString);		
		return query;
	}
	
	/**
	 * 创建 SQL 查询对象
	 * @param sqlString
	 * @param parameter
	 * @return
	 */
	private SQLQuery createSqlQuery(String sqlString){
		SQLQuery query = getSession().createSQLQuery(sqlString);		
		return query;
	}
    
    /**
	 * 创建Criteria对象带属性比较
	 * 
	 * @param <T>
	 * @param entityClass
	 * @param criterions
	 * @return
	 */
	private <T> Criteria createCriteria(Class<T> entityClass,
			Criterion... criterions) {
		Criteria criteria = getSession().createCriteria(entityClass);
		for (Criterion c : criterions) {
			criteria.add(c);
		}
		return criteria;
	}

	@Override
	public int updateByHQL(String hql) {
		return createQuery(hql).executeUpdate();
	}

	@Override
	public int updateBySql(String sqlString) {
		return createSqlQuery(sqlString).executeUpdate();
	}
	
	@Override
	public int executeHQL(String hql){
		Query query = getSession().createQuery(hql);
		return query.executeUpdate();
	}
}
