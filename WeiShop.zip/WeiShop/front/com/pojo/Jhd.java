package com.pojo;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Jhd entity.
 * 
 * @author MyEclipse Persistence Tools


@Entity
@Table(name = "Jhd") */
public class Jhd implements java.io.Serializable {

	private static final long serialVersionUID = 8921217505718390290L;
	private String djid;
	private Integer gysid;
	private String gysname;
	private Date riqi;
	private Double yfje;
	private Double sfje;
	private String jystate;
	private Integer userid;
	private String username;
	public Integer getSp_id() {
		return sp_id;
	}

	public void setSp_id(Integer sp_id) {
		this.sp_id = sp_id;
	}

	public String getSp_name() {
		return sp_name;
	}

	public void setSp_name(String sp_name) {
		this.sp_name = sp_name;
	}

	private String bz;
	private Integer sp_id;
	private String sp_name;

	// Constructors

	/** default constructor */
	public Jhd() {
	}

	/** minimal constructor */
	public Jhd(Date riqi) {
		this.riqi = riqi;
	}

	/** full constructor */
	public Jhd(Integer gysid, String gysname, Date riqi, Double yfje,
			Double sfje, String jystate, Integer userid, String username,
			String bz) {
		this.gysid = gysid;
		this.gysname = gysname;
		this.riqi = riqi;
		this.yfje = yfje;
		this.sfje = sfje;
		this.jystate = jystate;
		this.userid = userid;
		this.username = username;
		this.bz = bz;
	}

	// Property accessors

	public String getDjid() {
		return this.djid;
	}

	public void setDjid(String djid) {
		this.djid = djid;
	}

	public Integer getGysid() {
		return this.gysid;
	}

	public void setGysid(Integer gysid) {
		this.gysid = gysid;
	}

	public String getGysname() {
		return this.gysname;
	}

	public void setGysname(String gysname) {
		this.gysname = gysname;
	}

	public Date getRiqi() {
		return this.riqi;
	}

	public void setRiqi(Date riqi) {
		this.riqi = riqi;
	}

	public Double getYfje() {
		return this.yfje;
	}

	public void setYfje(Double yfje) {
		this.yfje = yfje;
	}

	public Double getSfje() {
		return this.sfje;
	}

	public void setSfje(Double sfje) {
		this.sfje = sfje;
	}

	public String getJystate() {
		return this.jystate;
	}

	public void setJystate(String jystate) {
		this.jystate = jystate;
	}

	public Integer getUserid() {
		return this.userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getBz() {
		return this.bz;
	}

	public void setBz(String bz) {
		this.bz = bz;
	}

}