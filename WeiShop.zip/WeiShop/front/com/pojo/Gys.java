package com.pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Gys entity.
 * 
 * @author MyEclipse Persistence Tools

@Entity
@Table(name = "Gys") */
public class Gys implements java.io.Serializable {

	private static final long serialVersionUID = -8760442688713633468L;
	private Integer gysid;
	private String name;
	private String lxren;
	private String lxtel;
	private String address;
	private String bz;
	
	@OneToMany(mappedBy="gysid")
	private Set<Thd> thds = new HashSet<Thd>(0);
	
	@OneToMany(mappedBy="gysid")
	private Set<Jhd> jhds = new HashSet<Jhd>(0);

	// Constructors

	/** default constructor */
	public Gys() {
	}

	/** full constructor */
	public Gys(String name, String lxren, String lxtel, String address,
			String bz, Set thds, Set jhds) {
		this.name = name;
		this.lxren = lxren;
		this.lxtel = lxtel;
		this.address = address;
		this.bz = bz;
		this.thds = thds;
		this.jhds = jhds;
	}

	// Property accessors

	public Integer getGysid() {
		return this.gysid;
	}

	public void setGysid(Integer gysid) {
		this.gysid = gysid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLxren() {
		return this.lxren;
	}

	public void setLxren(String lxren) {
		this.lxren = lxren;
	}

	public String getLxtel() {
		return this.lxtel;
	}

	public void setLxtel(String lxtel) {
		this.lxtel = lxtel;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBz() {
		return this.bz;
	}

	public void setBz(String bz) {
		this.bz = bz;
	}

	public Set getThds() {
		return this.thds;
	}

	public void setThds(Set thds) {
		this.thds = thds;
	}

	public Set getJhds() {
		return this.jhds;
	}

	public void setJhds(Set jhds) {
		this.jhds = jhds;
	}

}