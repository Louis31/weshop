package com.pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Spdw entity.
 * 
 * @author MyEclipse Persistence Tools

@Entity
@Table(name = "Spdw") */
public class Spdw implements java.io.Serializable {

	private static final long serialVersionUID = 3784726626866847687L;
	private Integer dwid;
	private String dwname;

	// Constructors

	/** default constructor */
	public Spdw() {
	}

	/** full constructor */
	public Spdw(String dwname) {
		this.dwname = dwname;
	}

	// Property accessors

	public Integer getDwid() {
		return this.dwid;
	}

	public void setDwid(Integer dwid) {
		this.dwid = dwid;
	}

	public String getDwname() {
		return this.dwname;
	}

	public void setDwname(String dwname) {
		this.dwname = dwname;
	}

}