package com.pojo;


public class SpxxImage implements java.io.Serializable {
     public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getSpid() {
		return spid;
	}
	public void setSpid(String spid) {
		this.spid = spid;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 7155729297461060384L;
	private Integer id;
     private String url;
     private String spid;
     private String content;
     
     
}
