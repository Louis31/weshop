package com.pojo;

public class Position implements java.io.Serializable{

	private static final long serialVersionUID = 7506749464739658374L;
	
	private Integer spid;
	private String spname;
	private String spcode;
	private Integer pid;
	
	public Position(){}
	
	public Integer getSpid() {
		return spid;
	}
	public void setSpid(Integer spid) {
		this.spid = spid;
	}
	public String getSpname() {
		return spname;
	}
	public void setSpname(String spname) {
		this.spname = spname;
	}
	public String getSpcode() {
		return spcode;
	}
	public void setSpcode(String spcode) {
		this.spcode = spcode;
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}

}
