package com.pojo;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

/**
 * Rolemenu entity.
 * 
 * @author MyEclipse Persistence Tools


@Entity
@Table(name = "Rolemenu") */
public class Rolemenu implements java.io.Serializable {

	private static final long serialVersionUID = 1925049626568104379L;
	
	@EmbeddedId
	private RolemenuId id;
	
	@ManyToOne
	@JoinColumn(name="roleid",nullable=false)
	@Fetch(FetchMode.SELECT)
	private Role role;
	
	@ManyToOne
	@JoinColumn(name="menuid",nullable=false)
	@Fetch(FetchMode.SELECT)
	private Menu menu;

	// Constructors

	/** default constructor */
	public Rolemenu() {
	}

	/** full constructor */
	public Rolemenu(RolemenuId id, Role role, Menu menu) {
		this.id = id;
		this.role = role;
		this.menu = menu;
	}

	// Property accessors

	public RolemenuId getId() {
		return this.id;
	}

	public void setId(RolemenuId id) {
		this.id = id;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}
	
	

}