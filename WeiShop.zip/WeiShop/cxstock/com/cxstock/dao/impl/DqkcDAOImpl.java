package com.cxstock.dao.impl;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.internal.CriteriaImpl;
import org.springframework.orm.hibernate4.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import com.cxstock.biz.kucun.dto.DqkcDTO;
import com.cxstock.dao.DqkcDAO;

@Repository
public class DqkcDAOImpl implements DqkcDAO {

	/*
	 * 当前库存查询 
	 */
	@SuppressWarnings("unchecked")
	public List getDqkcByParams(Integer kfid,Integer lbid,String search) {
		Connection conn = null;
		Statement stm = null;
		ResultSet rs = null;
		List list = new ArrayList();
		StringBuffer sql = new StringBuffer("select s.spid,s.spname,s.lbname,s.xinghao,s.kcsl,d.xssl,s.scjj,s.jhprice,s.chprice,s.kczj,s.dw,s.csname,s.bz from (select * from spxx where 1=1");
		if(lbid!=null&&!lbid.equals(0)){
			sql.append(" and lbid=");
			sql.append(lbid);
		}
		if(search!=null&&!"".equals(search)){
			sql.append(" and spid like '%");
			sql.append(search);
			sql.append("%' or spname like '%");
			sql.append(search);
			sql.append("%'");
		}
		sql.append(") as s left join (select spid,sum(sl)as xssl from ckdsp group by spid) as d on(s.spid=d.spid)");
		try {			
			conn = getConnection();
			stm = conn.createStatement();
			rs = stm.executeQuery(sql.toString());
			while(rs.next()){
				DqkcDTO dto = new DqkcDTO();
				dto.setSpid(rs.getString(1));
				dto.setSpname(rs.getString(2));
				dto.setLbname(rs.getString(3));
				dto.setXinghao(rs.getString(4));
				dto.setKcsl(rs.getInt(5));
				dto.setXsll(rs.getInt(6));
				dto.setScjj(rs.getDouble(7));
				dto.setJhprice(rs.getDouble(8));
				dto.setChprice(rs.getDouble(9));
				dto.setKczj(rs.getDouble(10));
				dto.setDw(rs.getString(11));
				dto.setCsname(rs.getString(12));
				dto.setBz(rs.getString(13));
				list.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
			
		} finally {
			try {
			    if(rs != null)
			       rs.close();
			    if(stm != null)
			    	stm.close();
			} catch (SQLException e) {
			    e.printStackTrace();
			    throw new RuntimeException(e.getMessage());	
			}
		}
		return list;
	}
	
	/**
	 * 注入一个sessionFactory属性,并注入到父类(HibernateDaoSupport)
	 * **/
	@Resource
	private SessionFactory sessionFactory;

	@Override
	public Session getSession() {
		// 事务必须是开启的(Required)，否则获取不到
		return sessionFactory.getCurrentSession();
	}
	
	 /**
		 * 创建 QL 查询对象
		 * @param qlString
		 * @param parameter
		 * @return
		 */
		private Query createQuery(String qlString){
			Query query = getSession().createQuery(qlString);		
			return query;
		}
		
		/**
		 * 创建 SQL 查询对象
		 * @param sqlString
		 * @param parameter
		 * @return
		 */
		private SQLQuery createSqlQuery(String sqlString){
			SQLQuery query = getSession().createSQLQuery(sqlString);		
			return query;
		}
	
	/** 保存或更新指定的持久化对象 */
	public void save(Object obj) {
		getSession().save(obj);
	}
	
	/** 保存或更新指定的持久化对象 */
	public void saveOrUpdate(Object obj) {
		getSession().saveOrUpdate(obj);
	}
	
	/** 删除指定ID的持久化对象 */
	public void deleteById(Class clazz, Serializable id) {
		getSession().delete(getSession().load(clazz, id));			
	}
	
	/** 删除指定ID的持久化对象 */
	public void delete(Object obj) {
		getSession().delete(obj);			
	}
	
	/** 加载指定ID的持久化对象 */
	public Object loadById(Class clazz, Serializable id) {
		return getSession().get(clazz, id);
	}
	
	/**加载满足条件的持久化对象*/
	public Object loadObject(String hql) {
		final String hql1 = hql;
		Object obj = null;
		List list = createQuery(hql1).list();
		if(list.size()>0)obj=list.get(0);	
		return obj;
	}
	
	/** 查询指定类的满足条件的持久化对象 */
	public List findByHql(String hql) {
		try{
			final String hql1 = hql;
			return  createQuery(hql1).list();
		}
		catch (Exception e) {
			e.printStackTrace();
		}return null;
	}
	
	/** 装载指定类的查询结果 */
	public List findInProperty(String clazz, String propertyName, String value) {
		String hql = "from "+clazz+" as model where model." + propertyName + " in (" + value + ")";
		return  createQuery(hql).list();
	}
	
	/** 装载指定类的查询结果 */
	public List findLikeProperty(String clazz, String propertyName, String value) {
		String hql = "from "+clazz+" as model where model."	+ propertyName + " like '"+value+"'";
		return createQuery(hql).list();
	}
	
	/** 装载指定类的查询结果 */
	public List findByProperty(String clazz, String propertyName, Object value) {
		String hql = "from "+clazz+" as model where model."	+ propertyName + "= "+value;
		return createQuery(hql).list();
	}
	
	/** 装载指定类的查询结果 */
	public List findByProperty(String clazz, String[] propertyName, Object[] value) {
		String hsql = "from "+clazz+" as model where 1=1";
		for (int i = 0; i < propertyName.length; i++) {
			hsql += " and model." + propertyName[i] + "= "+value[i];
		}
		return createQuery(hsql).list();
	}
	
	/** 装载指定类的所有持久化对象 */
	public List listAll(String clazz) {
		return createQuery("from "+clazz).list();
	}
	
	/** 条件更新数据 */
	public int update(String hql) {
		final String hql1 = hql; 
		return createQuery(hql1).executeUpdate();
	}
	// -------------- Query Tools --------------
	/** 
     * 去除qlString的select子句。 
     * @param qlString
     * @return 
     */  
    private String removeSelect(String qlString){  
        int beginPos = qlString.toLowerCase().indexOf("from");  
        return qlString.substring(beginPos);  
    }  
      
    /** 
     * 去除hql的orderBy子句。 
     * @param qlString
     * @return 
     */  
    private String removeOrders(String qlString) {  
        Pattern p = Pattern.compile("order\\s*by[\\w|\\W|\\s|\\S]*", Pattern.CASE_INSENSITIVE);  
        Matcher m = p.matcher(qlString);  
        StringBuffer sb = new StringBuffer();  
        while (m.find()) {  
            m.appendReplacement(sb, "");  
        }
        m.appendTail(sb);
        return sb.toString();  
    } 
	public int countByCriteria(Criteria criteria) {
		Criteria queryCriteria = criteria;
		int totalCount = 0;
		try {
			// Get orders
			Field field = CriteriaImpl.class.getDeclaredField("orderEntries");
			field.setAccessible(true);
			List orderEntrys = (List)field.get(queryCriteria);
			// Remove orders
			field.set(queryCriteria, new ArrayList());
			// Get count
			queryCriteria.setProjection(Projections.rowCount());
			totalCount = Integer.valueOf(queryCriteria.uniqueResult().toString());
			// Clean count
			queryCriteria.setProjection(null);
			// Restore orders
			field.set(queryCriteria, orderEntrys);
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return totalCount;
	}
	/** 统计指定类的所有持久化对象 */
	public int countAll(String clazz) {
		Criteria crit = getSession().createCriteria(clazz);
		return countByCriteria(crit);
//		final String hql = "select count(*) from "+clazz;
//		Long count = (Long)getHibernateTemplate().execute(new HibernateCallback(){
//			public Object doInHibernate(Session session) throws HibernateException{
//				Query query = session.createQuery(hql);
//				query.setMaxResults(1);
//				return query.uniqueResult();
//			}
//		});	
//		return count.intValue();
	}

	/** 统计指定类的查询结果 */
	public int countQuery(String hql) {
		String countQlString = "select count(*) " + removeSelect(removeOrders(hql)); 
		Query query = createQuery(countQlString);
		List<Object> list = query.list();		
        if (list.size() > 0){
        	return Integer.valueOf(list.get(0).toString());
        }else{
        	return 0;
        }		
	}
	
	/** 分页装载指定类的查询结果 */
	public List findInProperty(String clazz, String propertyName, String value, int start, int limit) {
		String hql = "from "+clazz+" as model where model." + propertyName + " in (" + value + ")";
		return this.findByHql(hql, start, limit);
	}
	
	/** 分页装载指定类的查询结果 */
	public List findLikeProperty(String clazz, String propertyName, String value, int start, int limit) {
		String hql = "from "+clazz+" as model where model."	+ propertyName + " like '"+value+"%'";
		return this.findByHql(hql, start, limit);
	}
	
	/** 分页装载指定类的查询结果 */
	public List findByProperty(String clazz, String propertyName, String value, int start, int limit) {
		String hql = "from "+clazz+" as model where model."	+ propertyName + "= '"+value+"'";
		return this.findByHql(hql, start, limit);
	}
	
	/** 分页装载指定类的查询结果 */
	public List findByProperty(String clazz, String[] propertyName, Object[] value, int start, int limit) {
		String hql = "from "+clazz+" as model where 1=1";
		for (int i = 0; i < propertyName.length; i++) {
			hql += " and model." + propertyName[i] + "= '"+value[i]+"'";
		}
		return this.findByHql(hql, start, limit);
	}

	/** 分页装载指定类的所有持久化对象 */
	public List listAll(String clazz, int start, int limit) {
		final int pStart = start;
		final int pLimit = limit;
		final String hql = "from "+clazz;
		Query pagequery = createQuery(hql); 
		    	// set page
		pagequery.setFirstResult(start);
		pagequery.setMaxResults(limit); 
		return pagequery.list();
//		List list = getHibernateTemplate().executeFind(new HibernateCallback(){
//			public Object doInHibernate(Session session) throws HibernateException{
//				Query query = session.createQuery(hql);
//				query.setMaxResults(pLimit);
//				query.setFirstResult(pStart);
//				List result = query.list();
//				if (!Hibernate.isInitialized(result))Hibernate.initialize(result);
//				return result;
//			}
//		});	
//		return list;
	}
	
	/** 分页查询指定类的满足条件的持久化对象 */
	public List findByHql(String hql, int start, int limit) {
		final int pStart = start;
		final int pLimit = limit;
		final String hql1 = hql;
		Query pagequery = createQuery(hql); 
    	// set page
       pagequery.setFirstResult(start);
       pagequery.setMaxResults(limit); 
       return pagequery.list();
//		return getHibernateTemplate().executeFind(new HibernateCallback(){
//			public Object doInHibernate(Session session) throws HibernateException{
//				Query query = session.createQuery(hql1);
//				query.setMaxResults(pLimit);
//				query.setFirstResult(pStart);
//				List result = query.list();
//				if (!Hibernate.isInitialized(result))Hibernate.initialize(result);
//				return result;
//			}
//		});	
	}
	/** 从连接池中取得一个JDBC连接 */
	@SuppressWarnings("deprecation")
	public Connection getConnection() {
		
		try {
			return SessionFactoryUtils.getDataSource(sessionFactory).getConnection();
		} catch (SQLException e) {
			return null;
		}
	}
		 
	/**  批量保存、修改 */
	public void saveOrUpdateAll(Collection collection) {
		for (Iterator iterator = collection.iterator(); iterator.hasNext();) {
			Object object = (Object) iterator.next();
			getSession().saveOrUpdate(object);
		}
		
	}

	/** 调用存储过程 */
	public void callProcedure(String call) {
		SQLQuery query = this.getSession().createSQLQuery(call);    
		query.executeUpdate();
	}

}
