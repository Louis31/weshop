package com.cxstock.biz.kucun.dto;


public class DqkcDTO {

	private String spid;
	private String spname;
	private String lbname;
	private String xinghao;
	private Integer kcsl;
	private Integer xsll;
	private Double scjj;
	private Double jhprice;
	private Double chprice;
	private Double kczj;
	private String dw;
	private String csname;
	private String bz;

	public DqkcDTO() {
	}

	public String getSpid() {
		return spid;
	}

	public void setSpid(String spid) {
		this.spid = spid;
	}

	public String getSpname() {
		return spname;
	}

	public void setSpname(String spname) {
		this.spname = spname;
	}

	public String getLbname() {
		return lbname;
	}

	public void setLbname(String lbname) {
		this.lbname = lbname;
	}

	public String getXinghao() {
		return xinghao;
	}

	public void setXinghao(String xinghao) {
		this.xinghao = xinghao;
	}

	public Integer getKcsl() {
		return kcsl;
	}

	public void setKcsl(Integer kcsl) {
		this.kcsl = kcsl;
	}

	public Integer getXsll() {
		return xsll;
	}

	public void setXsll(Integer xsll) {
		this.xsll = xsll;
	}

	public Double getScjj() {
		return scjj;
	}

	public void setScjj(Double scjj) {
		this.scjj = scjj;
	}

	public Double getJhprice() {
		return jhprice;
	}

	public void setJhprice(Double jhprice) {
		this.jhprice = jhprice;
	}

	public Double getChprice() {
		return chprice;
	}

	public void setChprice(Double chprice) {
		this.chprice = chprice;
	}

	public Double getKczj() {
		return kczj;
	}

	public void setKczj(Double kczj) {
		this.kczj = kczj;
	}

	public String getDw() {
		return dw;
	}

	public void setDw(String dw) {
		this.dw = dw;
	}

	public String getCsname() {
		return csname;
	}

	public void setCsname(String csname) {
		this.csname = csname;
	}

	public String getBz() {
		return bz;
	}

	public void setBz(String bz) {
		this.bz = bz;
	}
	

}
