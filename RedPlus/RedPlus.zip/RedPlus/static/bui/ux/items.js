
/**
公共常量
*/
BUI.data={};
BUI.data.actionType=BUI.data.actionType ||{
	TBAR_ACTION:0,
	COLUMN_ACTION:1
};
