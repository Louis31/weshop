/**
 * @fileOverview \u9009\u62e9\u6846\u547d\u540d\u7a7a\u95f4\u5165\u53e3\u6587\u4ef6
 * @ignore
 */define("bui/extensions/multiselect",["bui/common","bui/extensions/multiselect/multilist","bui/extensions/multiselect/multilistpicker","bui/extensions/multiselect/multiselect","bui/extensions/search"],function(e){var t=e("bui/common"),n=e("bui/extensions/multiselect/multiselect");return n});
